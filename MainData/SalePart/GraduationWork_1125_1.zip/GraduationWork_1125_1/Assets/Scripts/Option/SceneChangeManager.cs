﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//---------------------------------------------
/// <summary>
/// シーン変移管理
/// </summary>
public class SceneChangeManager : SingletonClass<SceneChangeManager>
{
    //---------------------------------------------
	/// <summary>
	/// シーン切り替え
	/// </summary>
	/// <param name="sName">次のシーン名</param>
    public void SceneChange(string sName)
	{
		//FadeOut

		//シーン切り替え
		SceneManager.LoadScene(sName);

		//FadeIn

	}
	//---------------------------------------------
}
