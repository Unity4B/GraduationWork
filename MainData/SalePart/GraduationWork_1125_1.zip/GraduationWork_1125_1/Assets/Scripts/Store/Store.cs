﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//---------------------------------------------
/// <summary>
/// 店
/// </summary>
public class Store
{
    //---------------------------------------------
    /// <summary>
    /// 店カテゴリ
    /// </summary>
    StoreManager.Category sCategory;
    /// <summary>
    /// ボーナスアイテム
    /// </summary>
    ItemCategory[] bonusItems = new ItemCategory[2];
    /// <summary>
    /// 店主の画像
    /// </summary>
    Sprite ownerSprite;
    /// <summary>
    /// 店の背景
    /// </summary>
    Sprite backSprite;
    /// <summary>
    /// 表示メッセージ
    /// </summary>
    List<string> message;
    //---------------------------------------------
    //プロパティ
    /// <summary>
    /// 店カテゴリ
    /// </summary>
    public StoreManager.Category SCategory
	{
        private set { this.sCategory = value; }
        get { return this.sCategory; }
    }
    /// <summary>
    /// ボーナスアイテム
    /// </summary>
    public ItemCategory[] BonusItems
	{
		private set { this.bonusItems = value;}
		get { return this.bonusItems; }
	}
    /// <summary>
    /// 店主の画像
    /// </summary>
    public Sprite OwnerSprite
	{
        private set { this.ownerSprite = value; }
		get { return this.ownerSprite; }
	}
    /// <summary>
    /// 店の背景
    /// </summary>
    public Sprite BackSprite
	{
        private set { this.backSprite = value; }
		get { return this.backSprite; }
	}
    /// <summary>
    /// 表示メッセージ
    /// </summary>
    public List<string> Message
	{
        private set { this.message = value; }
        get { return this.message; }
	}
    //---------------------------------------------
    /// <summary>
    /// コンストラクタ
    /// </summary>
    /// <param name="sCategory_">店カテゴリ</param>
    /// <param name="bonusItems">ボーナスアイテム</param>
    public Store(StoreManager.Category sCategory_,ItemCategory[] bonusItems)
	{
        SCategory = sCategory_;
        BonusItems = bonusItems;

        //データ読み込み
        DataLoad();
	}
    //---------------------------------------------
    void DataLoad()
	{
        string num = ((int)SCategory).ToString();

        ////店主の画像の変更
        OwnerSprite = FileLoad.SpriteDataLoadResource("Store/Owner/owner" + num);

        ////店の背景の画像変更
        BackSprite = FileLoad.SpriteDataLoadResource("Store/Back/storeback" + num);

        ////店主のメッセージ変更
        Message = FileLoad.DataLoadResource("Store/storemessage" + num);
    }
    //---------------------------------------------
    /// <summary>
    /// ボーナス対象かチェック
    /// </summary>
    /// <param name="category">確認したいアイテムのカテゴリ</param>
    /// <returns></returns>
    public bool CheckBonusItem(ItemCategory category)
	{
        bool isBounus = false;
        for (int i = 0; i < BonusItems.Length; i++)
        {
            if (category == BonusItems[i]) { isBounus = true; }
        }
        return isBounus;
    }
}
