﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// アイテム管理
/// </summary>
public class ItemManager : SingletonClass<ItemManager>
{
	//-------------------------------------------------------------------------------
	//アイテムリスト
	public List<Item> itemList;
	//アイテム画像リスト
	public Sprite[] itemSprites;
	//-------------------------------------------------------------------------------
	protected override void Awake()
	{
		base.Awake();

		//アイテムデータの読み込み
		this.itemList = new List<Item>();
		Instance.ItemDataLoad();	

		//アイテム画像の読み込み
		this.itemSprites = new Sprite[this.itemList.Count];
		Instance.ItemSpriteLoad();
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// アイテムデータの読み込み・反映
	/// </summary>
	void ItemDataLoad()
	{
		//テキストフェイルからアイテムデータを読み込む
		List<string> itemData = FileLoad.DataLoadResource("item");

		//要素分繰り返す
		for (int i = 0; i < itemData.Count; i++)
		{
			//文字列を分割してアイテムを作成
			string line = itemData[i];

			//文字列から作成するアイテムのカテゴリを決定
			ItemCategory itemCategory = ItemCategory.NONE;
			switch(line.Split(',')[2])
			{
				case "植物":	itemCategory = ItemCategory.PLANT;	break;
				case "薬品":	itemCategory = ItemCategory.DLUG;	break;
				case "小道具":	itemCategory = ItemCategory.TOOL;	break;
				case "書物":	itemCategory = ItemCategory.BOOK;	break;
				case "武器":	itemCategory = ItemCategory.WEAPON; break;
				case "防具":	itemCategory = ItemCategory.ARMOR;	break;
				case "宝石":	itemCategory = ItemCategory.JEWEL;	break;
				case "指輪":	itemCategory = ItemCategory.RING;	break;
				case "食物":	itemCategory = ItemCategory.FOOD;	break;
			}

			//アイテム作成
			Item item = new Item
				(
					int.Parse(line.Split(',')[0]),	//アイテム番号
					line.Split(',')[1],				//アイテム名
					itemCategory,					//アイテムカテゴリ
					int.Parse(line.Split(',')[3])	//値段
				);

			//アイテムリストに追加
			this.itemList.Add(item);
		}
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// アイテム画像の読み込み・反映
	/// </summary>
	void ItemSpriteLoad()
	{
		//要素分繰り返す
		for(int i =0; i < this.itemSprites.Length;i++)
		{
			//読み込んで反映
			this.itemSprites[i] = FileLoad.SpriteDataLoadResource("Item/item" + (i + 1).ToString());
		}
	}
}
