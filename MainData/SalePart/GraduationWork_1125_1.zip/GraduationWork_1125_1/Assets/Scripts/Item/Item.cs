﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// アイテムの種類
/// </summary>
public enum ItemCategory
{
	NONE = -1,
	/// <summary>
	/// 植物
	/// </summary>
	PLANT = 0,
	/// <summary>
	/// 薬品
	/// </summary>
	DLUG = 1,
	/// <summary>
	/// 小道具
	/// </summary>
	TOOL = 2,
	/// <summary>
	/// 書物
	/// </summary>
	BOOK = 3,
	/// <summary>
	/// 武器
	/// </summary>
	WEAPON = 4,
	/// <summary>
	/// 防具
	/// </summary>
	ARMOR = 5,
	/// <summary>
	/// 宝石
	/// </summary>
	JEWEL = 6,
	/// <summary>
	/// 指輪
	/// </summary>
	RING = 7,
	/// <summary>
	/// 食物
	/// </summary>
	FOOD = 8,
}
//-------------------------------------------------------------------------------
/// <summary>
/// アイテムクラス
/// </summary>
public class Item
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// アイテム番号
	/// </summary>
	int num;
	/// <summary>
	/// アイテム名
	/// </summary>
	string iName;
	/// <summary>
	/// カテゴリ名
	/// </summary>
	ItemCategory category;
	/// <summary>
	/// 値段
	/// </summary>
	int price;
	//-------------------------------------------------------------------------------
	//プロパティ
	/// <summary>
	/// アイテム番号
	/// </summary>
	public int Num
	{
		private set { this.num = value; }
		get { return this.num; }
	}
	/// <summary>
	/// アイテム名
	/// </summary>
	public string IName
	{
		private set { this.iName = value; }
		get	{ return this.iName; }
	}
	/// <summary>
	/// カテゴリ名
	/// </summary>
	public ItemCategory Category
	{
		private set { this.category = value; }
		get { return this.category; }
	}
	/// <summary>
	/// 値段
	/// </summary>
	public int Price
	{
		private set { this.price = value; }
		get { return this.price; }
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// コンストラクタ
	/// </summary>
	/// <param name="num_">番号</param>
	/// <param name="iName_">アイテム名</param>
	/// <param name="category_">カテゴリ名</param>
	/// <param name="price_">値段</param>
	public Item(int num_, string iName_, ItemCategory category_, int price_)
	{
		Num = num_;
		IName = iName_;
		Category = category_;
		Price = price_;
	}
	//-------------------------------------------------------------------------------
}
