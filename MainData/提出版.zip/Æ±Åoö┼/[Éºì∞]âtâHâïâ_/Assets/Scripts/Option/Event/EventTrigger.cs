﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 接触時にイベントを発動させる
/// </summary>
public class EventTrigger : MonoBehaviour
{
	[SerializeField] string eventFlagName = "";

	private void OnTriggerEnter2D(Collider2D col)
	{
		//プレイヤーと接触した場合
		if (col.gameObject.CompareTag("Player"))
		{
			//イベントスタート
			EventManager.Instance.EventStart(this.eventFlagName);

			//自分を無効化
			this.enabled = false;
		}
	}

}
