﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

//-------------------------------------------------------------------------------
/// <summary>
/// イベントメッセージ
/// </summary>
public class EventMessage : SingletonClass<EventMessage>
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// キー画像表示
	/// </summary>
	[SerializeField] KeyTypeController keyTypeClass = null;
	/// <summary>
	/// 反映するテキスト
	/// </summary>
	[SerializeField] Text messageText = null;
	/// <summary>
	/// 反映するウィンドウ
	/// </summary>
	[SerializeField] Canvas textCanvas = null;
	/// <summary>
	/// イベント開始時間
	/// </summary>
	float eventStartTime;
	/// <summary>
	/// メッセージ出力中か
	/// </summary>
	bool isMessageDraw;
	/// <summary>
	/// メッセージ出力を終わらせるか
	/// </summary>
	bool isMessageDrawEnd;
	/// <summary>
	/// メッセージが消えるまでの時間
	/// </summary>
	[Header("メッセージが消えるまでの時間")]
	[SerializeField] float eventMessageTime = 1.0f;
	//-------------------------------------------------------------------------------
	protected override void AwakeInitialize()
	{
		TextActive(false);
		this.isMessageDraw = false;
		this.isMessageDrawEnd = false;
	}
	//-------------------------------------------------------------------------------
	void Update()
	{
		//メッセージ出力中にアクションボタンが押された場合
		if(this.isMessageDraw && InputManager.Instance.input.ActionKeyDown())
		{
			this.isMessageDrawEnd = true;
		}
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メッセージを表示する
	/// </summary>
	/// <param name="message_">表示するメッセージ</param>
	public void MessageActive(string message_)
	{
		TextActive(true);

		//メッセージ表示開始
		StartCoroutine(MessageDraw(message_));

	}
	/// <summary>
	/// メッセージを表示する
	/// </summary>
	/// <param name="message_">表示するメッセージ</param>
	/// <param name="isMessageDrawEnd_">表示を即するか</param>
	public void MessageActive(string message_,bool isMessageDrawEnd_)
	{
		TextActive(true);

		//メッセージ表示開始
		StartCoroutine(MessageDraw(message_));

		//メッセージ出力即終了
		this.isMessageDrawEnd = isMessageDrawEnd_;

	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// テキストの表示・非表示
	/// </summary>
	/// <param name="isActive">有効にするか</param>
	void TextActive(bool isActive)
	{
		this.textCanvas.gameObject.SetActive(isActive);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メッセージ表示終了条件設定
	/// </summary>
	/// <param name="data">設定する文字</param>
	/// <returns></returns>
	public IsAction MessageAction(string data)
	{
		IsAction action = (()=>true);
		//終了条件分岐
		//メッセージ出力終了という条件も追加
		switch (data)
		{
			//アクションボタンが押されたか
			case "Action":		action = (() => InputManager.Instance.input.ActionKeyDown() && this.isMessageDraw == false); break;
			//横入力があったか
			case "Horizontal":	action = (() => InputManager.Instance.input.AxisHorizontal() != 0.0f && this.isMessageDraw == false); break;
			//ジャンプ入力があったか
			case "Jump":		action = (() => InputManager.Instance.input.JumpKeyDown() && this.isMessageDraw == false); break;
			//ジャンプ入力があったか
			case "Walljump":	action = (() => EventObject.Instance.CheckWallJump() && this.isMessageDraw == false); break;
			//時間経過か
			case "Time":		action = (() => CheckMessageTime() && this.isMessageDraw == false); break;
			//入力がない場合、時間経過 or アクションボタンで次へ
			default:			action = (() => (InputManager.Instance.input.ActionKeyDown() || CheckMessageTime()) && this.isMessageDraw == false); break;
		}


		//終了条件の反映
		SetMessageActionKeyImage(data);

		return action;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メッセージイベント終了時の処理
	/// </summary>
	/// <returns></returns>
	public void MessageEnd()
	{
		//終了時の処理
		TextActive(false);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メッセージ終了条件のキー画像を設定
	/// </summary>
	/// <param name = "kName">設定する文字</param>
	void SetMessageActionKeyImage(string kName)
	{
		KEYTYPE kType = KEYTYPE.NONE;
		switch(kName)
		{
			case "Action":	kType = KEYTYPE.ACTION; break;
			case "Jump":	kType = KEYTYPE.JUMP;	break;
		}
		this.keyTypeClass.SetKeySprite(kType);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 表示してから時間が経過したか
	/// </summary>
	/// <returns></returns>
	bool CheckMessageTime()
	{
		return Time.time - this.eventStartTime >= this.eventMessageTime;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// テキストメッセージを表示していくコルーチン
	/// </summary>
	/// <returns></returns>
	IEnumerator MessageDraw(string message_)
	{
		//メッセージ出力中
		this.isMessageDraw = true;

		string message = "";
		//メッセージの分だけ1文字ずつ追加
		for(int i = 0; i < message_.Length; i++)
		{
			//一文字をとる
			char c = message_[i];

			//改行判定($が改行合図)
			if(c == '$') { message += "\n"; continue; }
			//タグ判定
			if(c == '<') 
			{
				//タグ終了までループしながら追加(#がタグ終了合図)
				for (; message_[i] != '#'; i++) 
				{
					message += message_[i]; 
				}
			}	
			//一文字追加
			else { message += c; }

			//表示
			this.messageText.text = message;

			//即終了要請が出ている場合、処理を繰り返す
			if (this.isMessageDrawEnd) { continue; }

			//SE
			SEController.Instance.Play("letterSE",0.7f);

			yield return new WaitForSeconds(0.05f);	//　秒待つ
		}

		//メッセージ出力終了
		this.isMessageDraw = false;
		this.isMessageDrawEnd = false;  //リセット

		//メッセージをすべて表示してからカウント
		//時間記録
		this.eventStartTime = Time.time;

		

		yield break;
	}

}
