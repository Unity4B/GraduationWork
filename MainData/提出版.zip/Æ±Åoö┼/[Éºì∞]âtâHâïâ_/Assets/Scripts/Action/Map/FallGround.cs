﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 崩れる床
/// </summary>
public class FallGround : GroundBase
{
    /// <summary>
    /// フィールド
    /// </summary>

    //-----------------------------------------------
    [SerializeField] GameObject spriteObj = null;   //スプライトがあるオブジェクト
    [SerializeField] float vibrationWidth = 0.05f;  //振動幅
    [SerializeField] float vibrationSpeed = 30.0f;  //振動速度
    [SerializeField] float fallTime = 1.0f;         //落下までの時間
    [SerializeField] float fallSpeed = 10.0f;       //落下速度
    [SerializeField] float returnTime = 5.0f;       //落下してから戻る時間

    bool isOn;
    bool isFall;
    bool isReturn;
    bool isPlayerStepOn;
    BoxCollider2D boxCol;
    Rigidbody2D rb;
    SpriteRenderer sr;
    Vector3 spriteDefaultPos;
    Vector3 groundDefaultPos;
    Vector2 fallVelocity;
    float timer = 0f;
    float fallingTimer = 0f;


    void Start()
    {
        boxCol = GetComponent<BoxCollider2D>();
        rb = GetComponent<Rigidbody2D>();

        spriteDefaultPos = spriteObj.transform.position;
        fallVelocity = new Vector2(0, -fallSpeed);
        groundDefaultPos = gameObject.transform.position;
        sr = spriteObj.GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        //プレイヤが1回でも乗ったらフラグオン
        if (isPlayerStepOn)
        {
            isOn = true;
            isPlayerStepOn = false;
        }

        //プレイヤが乗ってから落ちるまでの間
        if(isOn && !isFall)
        {
            //振動する
            spriteObj.transform.position = spriteDefaultPos + new Vector3(Mathf.Sin(timer * vibrationSpeed) * vibrationWidth, 0, 0);

            //一定時間たったら落ちる
            if(timer>fallTime)
            {
                isFall = true;
            }

            timer += Time.deltaTime;
        }

        //一定時間明滅して戻ってくる
        if(isReturn)
        {
            StartCoroutine(SpriteFlashing(isReturn));
        }
    }

    void FixedUpdate()
    {
        //落下中
        if(isFall)
        {
            rb.velocity = fallVelocity;

            //一定時間だつと元の位置に戻る
            if(fallingTimer > returnTime)
            {
                isReturn = true;
                transform.position = groundDefaultPos;
                rb.velocity = Vector2.zero;
                isFall = false;
                timer = 0f;
                fallingTimer = 0f;
            }
            else
            {
                fallingTimer += Time.deltaTime;
                isOn = false;
            }
        }
    }

    /// <summary>
    /// 点滅
    /// </summary>
    /// <param name="check_">任意の判定</param>
    /// <returns></returns>
    IEnumerator SpriteFlashing(bool check_)
    {
        //無敵時間中の点滅
        for (int i = 0; i < 5; i++)
        {
            sr.enabled = false;
            yield return new WaitForSeconds(0.05f);
            sr.enabled = true;
            yield return new WaitForSeconds(0.05f);
        }
        isReturn = false;
        yield return null;
    }

    protected override void PlayerStayCollision(Collision2D collision)
    {
        isPlayerStepOn = true;
    }
}
