﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// 12/01 23:14 更新
//-------------------------------------------------------------------------------
/// <summary>
/// コントローラー入力
/// </summary>
public class InputController : InputBase
{
	bool isDownKey;
	bool isLeftKey;
	bool isRightKey;
	bool isUpKey;

	public InputController()
	{
		this.type = INPUTTYPE.CONROLLER;

		this.isDownKey = false;
		this.isLeftKey = false;
		this.isRightKey = false;
		this.isUpKey = false;
	}

	public override bool ActionKeyDown()
	{
		return Input.GetKeyDown(KeyCode.Joystick1Button0);
	}

	public override bool ActionKeyOn()
	{
		return Input.GetKey(KeyCode.Joystick1Button0);
	}

	public override bool ActionKeyUp()
	{
		return Input.GetKeyUp(KeyCode.Joystick1Button0);
	}

	public override bool CanselKeyDown()
	{
		return Input.GetKeyDown(KeyCode.Joystick1Button1);
	}


	public override bool JumpKeyDown()
	{
		return Input.GetKeyDown(KeyCode.Joystick1Button1);
	}

	public override bool MenuKeyDown()
	{
		return Input.GetKeyDown(KeyCode.Joystick1Button7);
	}

	public override bool DownKeyDown()
	{
		//キーを最初に押している場合
		if(!this.isDownKey && Input.GetAxis("D_Pad_V") == -1.0f)
		{
			this.isDownKey = true;
			return true;
		}
		//キーを離している場合
		else if(Input.GetAxis("D_Pad_V") > -1.0f)
		{
			this.isDownKey = false;
		}

		return false;
	}

	public override bool DownKeyOn()
	{
		if(Input.GetAxis("D_Pad_V") == -1.0f) { return true; }
		return false;
	}

	public override bool DownKeyUp()
	{
		//キーを離した場合
		if (this.isDownKey && Input.GetAxis("D_Pad_V") != -1.0f) 
		{
			this.isDownKey = false;
			return true; 
		}
		//キーを押している場合
		else if(Input.GetAxis("D_Pad_V") == -1.0f)
		{
			this.isDownKey = true;
		}

		return false;
	}
	public override bool LeftKeyDown()
	{
		//キーを最初に押している場合
		if (!this.isLeftKey && Input.GetAxis("D_Pad_H") == -1.0f)
		{
			this.isLeftKey = true;
			return true;
		}
		//キーを離している場合
		else if (Input.GetAxis("D_Pad_H") > -1.0f)
		{
			this.isLeftKey = false;
		}

		return false;
	}

	public override bool LeftKeyOn()
	{
		if (Input.GetAxis("D_Pad_H") == -1.0f) { return true; }
		return false;
	}

	public override bool LeftKeyUp()
	{
		//キーを離した場合
		if (this.isLeftKey && Input.GetAxis("D_Pad_H") != -1.0f)
		{
			this.isLeftKey = false;
			return true;
		}
		//キーを押している場合
		else if (Input.GetAxis("D_Pad_H") == -1.0f)
		{
			this.isLeftKey = true;
		}
		return false;
	}

	public override bool RightKeyDown()
	{
		//キーを最初に押している場合
		if (!this.isRightKey && Input.GetAxis("D_Pad_H") == 1.0f)
		{
			this.isRightKey = true;
			return true;
		}
		//キーを離している場合
		else if (Input.GetAxis("D_Pad_H") < 1.0f)
		{
			this.isRightKey = false;
		}
		return false;
	}

	public override bool RightKeyOn()
	{
		if (Input.GetAxis("D_Pad_H") == 1.0f) { return true; }
		return false;
	}

	public override bool RightKeyUp()
	{
		//キーを離した場合
		if (this.isRightKey && Input.GetAxis("D_Pad_H") != 1.0f)
		{
			this.isRightKey = false;
			return true;
		}
		//キーを押している場合
		else if (Input.GetAxis("D_Pad_H") == 1.0f)
		{
			this.isRightKey = true;
		}
		return false;
	}

	public override bool UpKeyDown()
	{
		//キーを最初に押している場合
		if (!this.isUpKey && Input.GetAxis("D_Pad_V") == 1.0f)
		{
			this.isUpKey = true;
			return true;
		}
		//キーを離している場合
		else if (Input.GetAxis("D_Pad_V") < 1.0f)
		{
			this.isUpKey = false;
		}
		return false;
	}

	public override bool UpKeyOn()
	{
		if (Input.GetAxis("D_Pad_V") == 1.0f) { return true; }
		return false;
	}

	public override bool UpKeyUp()
	{
		//キーを離した場合
		if (this.isUpKey && Input.GetAxis("D_Pad_V") != 1.0f)
		{
			this.isUpKey = false;
			return true;
		}
		//キーを押している場合
		else if (Input.GetAxis("D_Pad_V") == 1.0f)
		{
			this.isUpKey = true;
		}
		return false;
	}

	public override float AxisVertical()
	{
		return Input.GetAxis("Vertical");
	}

	public override float AxisHorizontal()
	{
		return Input.GetAxis("Horizontal");
	}
	//伊東　12/2　追加
	public override float CurveHorizontal()
	{
		return Input.GetAxisRaw("Horizontal");
	}

	public override bool ExitKeyDown()
	{
		return Input.GetKeyDown(KeyCode.Joystick1Button6);
	}
}
