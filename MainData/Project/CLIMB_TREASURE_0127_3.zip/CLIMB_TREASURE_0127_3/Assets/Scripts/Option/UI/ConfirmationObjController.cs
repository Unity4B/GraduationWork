﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

//-------------------------------------------------------------------------------
/// <summary>
/// 確認UI表示
/// </summary>
public class ConfirmationObjController : SingletonClass<ConfirmationObjController>
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 「はい」の場合の処理を格納
	/// </summary>
	UnityAction yesAction;
	/// <summary>
	/// 「いいえ」の場合の処理を格納
	/// </summary>
	UnityAction noAction;

	/// <summary>
	/// 使用するCanvas
	/// </summary>
	[SerializeField] Canvas canvas = null;
	/// <summary>
	/// 使用するText
	/// </summary>
	[SerializeField] Text messageText = null;
	/// <summary>
	/// 使用するボタン選択クラス
	/// </summary>
	[SerializeField] ButtonSelecter buttonClass = null;
	//-------------------------------------------------------------------------------
	protected override void AwakeInitialize()
	{
		DontDestroyOnLoad(gameObject);


		UIActive(false);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// UI表示などの有効・無効化
	/// </summary>
	/// <param name="isActive">有効にするか</param>
	void UIActive(bool isActive)
	{
		//Canvas
		this.canvas.enabled = isActive;
		//選択機能
		this.buttonClass.enabled = isActive;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 確認UIアクティブ
	/// </summary>
	/// <param name="yesAction_">「はい」選択時の処理</param>
	/// <param name="noAction_">「いいえ」選択時の処理</param>
	/// <param name="message">確認する文言</param>
	public void Active(UnityAction yesAction_,UnityAction noAction_,string message)
	{
		this.yesAction = yesAction_;
		this.noAction = noAction_;
		//メッセージ表示
		this.messageText.text = message;

		UIActive(true);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 「はい」の処理を実行する
	/// </summary>
	public void YesAction()
	{
		UIActive(false);
		if(this.yesAction == null) { return; }

		this.yesAction.Invoke();
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 「いいえ」の処理を実行する
	/// </summary>
	public void NoAction()
	{
		UIActive(false);
		if (this.noAction == null) { return; }

		this.noAction.Invoke();
	}
	//-------------------------------------------------------------------------------
}
