﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 足場の共通部分
/// </summary>
public class GroundBase : MonoBehaviour
{
    void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.transform.CompareTag("Player"))
        {
            if (collision.transform.GetComponent<PlayerMove>().isGrounded)
            {
                PlayerStayCollision(collision);
            }
        }
    }

    void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.transform.CompareTag("Player"))
        {
            PlayerExitCollision(collision);
        }
    }

    protected virtual void PlayerStayCollision(Collision2D collision)
    {
        collision.collider.transform.SetParent(transform);
    }

    protected virtual void PlayerExitCollision(Collision2D collision)
    {
        collision.collider.transform.SetParent(null);
    }
}
