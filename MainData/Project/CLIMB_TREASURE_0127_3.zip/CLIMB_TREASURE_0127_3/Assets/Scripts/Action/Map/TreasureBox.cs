﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//-------------------------------------------------------------------------------
/// <summary>
/// 宝箱
/// </summary>
public class TreasureBox : MonoBehaviour
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// ステージで取得可能なアイテムカテゴリの配列
    /// </summary>
    public ItemManager.Category[] itemTable;
    /// <summary>
    /// すでに開けたか
    /// </summary>
    bool isOpen;
    /// <summary>
    /// 操作するアニメーター
    /// </summary>
    [SerializeField] Animator anim = null;
    /// <summary>
    /// レア度テーブル
    /// </summary>
    [Header("レア度確率 1 ～ 100")]
    [SerializeField] int[] rarityTable = new int[4];
    [Header("格納しているアイテム番号")]
    [SerializeField] int itemNum = 1;
    //-------------------------------------------------------------------------------
    void Start()
    {
        //ステージのアイテムカテゴリテーブルを取得
        try
        {
            this.itemTable = ItemManager.Instance.stageItemCategory[SceneManager.GetActiveScene().name];
        }
        //見つからなかった場合
        catch(System.Exception e_)
		{
            Debug.LogWarning("アイテムカテゴリテーブルが取得できませんでした：" + SceneManager.GetActiveScene().name + "\nデフォルトでFOODを指定します。\n" + e_.Message);
            this.itemTable = new ItemManager.Category[] { ItemManager.Category.FOOD };
		}

        this.isOpen = false;

        //確率設定
        for (int i = 1; i < this.rarityTable.Length; i++)
        {
            this.rarityTable[i] += this.rarityTable[i - 1];
        }

        //仕様アイテムを使っている場合は特殊処理
        //抽選
        this.itemNum = ItemDraw();
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 出るアイテムを抽選（出たアイテムの番号で返す）
    /// </summary>
    /// <returns>アイテム番号</returns>
    protected virtual int ItemDraw()
	{
        //ランダムにカテゴリを取得
        int tmp = Random.Range(0,this.itemTable.Length);

        //取得するアイテムカテゴリ決定
        int category = (int)this.itemTable[tmp];

        //アイテムのレア度確定
        tmp = Random.Range(0, 100);   //0～99

        //レアリティ１の範囲の場合、レア度１
        if (tmp < this.rarityTable[0]) { tmp = 1; }
        //レアリティ２の範囲の場合、レア度２
        else if (tmp < this.rarityTable[1]) { tmp = 2; }
        //レアリティ３の範囲の場合、レア度３
        else if (tmp < this.rarityTable[2]) { tmp = 3; }
        //レアリティ４の範囲の場合、レア度４
        else if (tmp < this.rarityTable[3]) { tmp = 4; }
        //エラー
        else { Debug.LogError("宝箱のレアリティが異常値でした。"); }

		//レアリティアップアイテムが有効な場合、レアリティ確認
		if (RarityUp.Instance.isActive) 
        {
			if (RarityUp.Instance.CheckRarityUP()) { tmp++; }
        }

        //アイテム番号決定
        return (category * 5) + tmp;

	}
    //-------------------------------------------------------------------------------
    //アイテムのレア度補正

    //-------------------------------------------------------------------------------
    /// <summary>
    /// 宝箱を開けるアニメーション
    /// </summary>
    void AnimationOpen()
	{
        anim.SetBool("isOpen", true);
	}
    //-------------------------------------------------------------------------------
    /// <summary>
    /// アイテム取得音
    /// </summary>
    protected virtual void ItemGetSEPlay()
	{
        SEController.Instance.Play("itemgetSE_1",1.0f);
	}
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 格納しているアイテム番号を返す処理
    /// </summary>
    /// <returns></returns>
    public int GetItem()
	{
        this.isOpen = true;
        //アニメーション
        AnimationOpen();
        //SE
        ItemGetSEPlay();

        return this.itemNum;
	}
    //-------------------------------------------------------------------------------
    /// <summary>
    /// すでに開いているかチェック
    /// </summary>
    /// <returns></returns>
    public bool CheckOpen()
	{
        return isOpen;
    }
    //-------------------------------------------------------------------------------
}
