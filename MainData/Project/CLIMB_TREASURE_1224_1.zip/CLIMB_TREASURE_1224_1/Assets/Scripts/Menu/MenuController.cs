﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// メニュー関連操作
/// </summary>
public class MenuController : SingletonClass<MenuController>
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// ボタンスクリプト（現在選択中のオブジェクト設定）
	/// </summary>
	[SerializeField] ButtonSelecter buttonClass = null;
	/// <summary>
	/// メニュー項目ごとのオブジェクト
	/// </summary>
	[Header("メニュー項目ごとのオブジェクト")]
	[SerializeField] GameObject[] menuObj = null;
	/// <summary>
	/// 現在選択中のメニューオブジェクト番号
	/// </summary>
	int nowButtonNum;
	/// <summary>
	/// 選択機能が有効か
	/// </summary>
	bool isSelectActive;
	//-------------------------------------------------------------------------------
	void Start()
	{
		gameObject.SetActive(false);

		this.isSelectActive = true;	

		//オブジェクト非アクティブ化
		foreach(GameObject obj in this.menuObj)
		{
			obj.SetActive(false);
		}
	}

	void Update()
	{
		//選択機能によって処理変更
		if (this.isSelectActive)
		{
			//選択、決定でメニューオブジェクトアクティブ
			if (InputManager.Instance.input.ActionKeyDown())
			{
				//現在選択中のボタンを受け取る
				this.nowButtonNum = this.buttonClass.GetNowButton();

				SelectChange(false);
			}
		}
		else
		{
			//キャンセルでメニューオブジェクト非アクティブ
			if (InputManager.Instance.input.CanselKeyDown())
			{
				SelectChange(true);
			}
		}
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メニューでの操作オブジェクト切り替え
	/// </summary>
	/// <param name="isActive">メニュー選択を有効にするか</param>
	public void SelectChange(bool isActive)
	{
		//ボタン選択機能有効・無効化
		this.buttonClass.enabled = isActive;

		//メニューオブジェクトをアクティブ・非アクティブ化
		MenuObjActive(nowButtonNum, !isActive);

		//選択機能アクティブ・非アクティブ化
		this.isSelectActive = isActive;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メニューオブジェクトの有効・無効化
	/// </summary>
	/// <param name="num">対象の配列番号</param>
	/// <param name="isActive">有効にするか</param>
	void MenuObjActive(int num,bool isActive)
	{
		//番号が配列範囲外なら処理中断
		if(num < 0  || this.menuObj.Length <= num) { Debug.LogWarning("MenuObjの配列外を指定しています。：" + num); return; }

		this.menuObj[num].SetActive(isActive);
	}
	//-------------------------------------------------------------------------------
	//使用したい処理（ボタンにて）
	/// <summary>
	/// ゲーム終了
	/// </summary>
	public void GameEnd()
	{
#if UNITY_EDITOR
		UnityEditor.EditorApplication.isPlaying = false;
#elif UNITY_STANDALONE
			UnityEngine.Application.Quit();
#endif

	}
	//-------------------------------------------------------------------------------
}
