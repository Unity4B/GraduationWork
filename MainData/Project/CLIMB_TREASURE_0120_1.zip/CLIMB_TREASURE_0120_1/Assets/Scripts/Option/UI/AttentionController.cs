﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------------------------------------
/// <summary>
/// 注意書き表示
/// </summary>
public class AttentionController : SingletonClass<AttentionController>
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 無効化までの秒数
	/// </summary>
	[SerializeField] float inActiveTime = 1.0f;
	/// <summary>
	/// 使用するCanvas
	/// </summary>
	[SerializeField] Canvas attentionCanvas = null;
	/// <summary>
	/// 使用するText
	/// </summary>
	[SerializeField] Text messageText = null;
	//-------------------------------------------------------------------------------
	protected override void AwakeInitialize()
	{
		DontDestroyOnLoad(this.attentionCanvas.gameObject);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 注意書きを表示する
	/// </summary>
	/// <param name="message">表示する文字列</param>
	public void ActiveAttention(string message)
	{
		//Invokeが発生している場合、キャンセル
		if (IsInvoking("InActive")) { CancelInvoke("InActive"); }


		//有効化
		this.attentionCanvas.enabled = true;
		this.messageText.text = message;

		//数秒後に無効化
		Invoke("InActive", this.inActiveTime);

	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 無効化
	/// </summary>
	void InActive()
	{
		this.attentionCanvas.enabled = false;
	}
}
