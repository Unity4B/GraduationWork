﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Timer : MonoBehaviour
{
    //空objectにアタッチしてください(clockManager)

    [Header("時計針")]
    [SerializeField] private GameObject needle = null;
    [Header("針更新速度")]
    [SerializeField] private float updateSpeed = 0.0f;

    //制限時間
    private int limit;
    //カウント可能か
    public bool isCount;

    private float time;
    float count;
    void Start()
    {
        //制限時間を受け取る
        this.limit = ActionManager.Instance.TimeLimit;
        this.isCount = true;

        needle.transform.eulerAngles = new Vector3(0, 0, 0);
        time = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        //カウント不可の場合、処理終了
        if (!this.isCount) { return; }

        time += Time.deltaTime;
        count += Time.deltaTime;
        if (count >= updateSpeed)
        {
            needle.transform.eulerAngles = new Vector3(0, 0, -time / limit * 360);
            count = 0;
        }
        //制限時間を過ぎた場合
        if (Timecount() >= 1f)
        {
            //アクションパート終了
            ActionManager.Instance.ActionGameEnd();
        }
    }
    public float Timecount()
    {
        return time/ limit;
    }
}
