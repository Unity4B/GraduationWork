﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// メニュー管理
/// </summary>
public class MenuManager : MonoBehaviour
{
    //-------------------------------------------------------------------------------
    void Update()
    {
        //メニューアクティブ・非アクティブ化
        if (InputManager.Instance.input.MenuKeyDown())
        {
            bool isActive = MenuController.Instance.gameObject.activeSelf;
            MenuController.Instance.gameObject.SetActive(!isActive);
        }
    }
    //-------------------------------------------------------------------------------
}
