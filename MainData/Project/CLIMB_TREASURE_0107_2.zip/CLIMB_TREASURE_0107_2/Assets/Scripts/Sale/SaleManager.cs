﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

//-------------------------------------------------------------------------------
/// <summary>
/// 売却管理
/// </summary>
public class SaleManager : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 店関連の管理クラス
	/// </summary>
	[SerializeField] StoreManager sManager = null;
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 売却後、売り上げを返す
	/// </summary>
	/// <param name="itemNum">売るアイテム番号</param>
	/// <returns></returns>
	int Sale(int itemNum)
	{
		//アイテム無しの場合、処理せず
		if(itemNum == -1) { return 0; }

		//番号のアイテムデータを取り出す
		Item item = ItemManager.Instance.itemList.FirstOrDefault<Item>(value=>value.Num == itemNum);

		//ボーナス対象かチェック
		bool isBonus = this.sManager.StoreSelect.CheckBonusItem(item.ICategory);

		//金額計算
		int price = 0;
		if (isBonus) { price = (int)((float)item.Price * 1.1f); }
		else { price = item.Price; }

		return price;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// プレイヤーのアイテムをすべて売却する
	/// </summary>
	public void AllItemSale()
	{
		int total = 0;

		//アイテムをコピー
		int[] itemNums = PlayData.Instance.itemNums;

		//持ってるアイテムをすべて売る
		for (int i = 0; i < PlayData.Instance.itemNums.Length; i++)
		{
			//売る
			total += Sale(itemNums[i]);
			//アイテム情報をリセット
			itemNums[i] = -1;
		}

		//所持金に追加
		PlayData.Instance.money += total;

		//メッセージ表記

		//シーン終了
		SceneChangeManager.Instance.SceneChange("StageSelectScene");	//仮
	}
	//-------------------------------------------------------------------------------
	//アイテムカタログに登録
	void ItemRegister(int num)
	{
		//プレイデータに登録
		PlayData.Instance.isGotItems[num - 1] = true;
	}
}
