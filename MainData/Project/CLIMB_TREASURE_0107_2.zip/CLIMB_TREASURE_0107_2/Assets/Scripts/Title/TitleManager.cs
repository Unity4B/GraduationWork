﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// タイトル管理
/// </summary>
public class TitleManager : SingletonClass<TitleManager>
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 新しくスタート
    /// </summary>
    public void NewGameStart()
	{
        
        SceneChangeManager.Instance.SceneChange("ActionForestMap");
	}
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 続きから
    /// </summary>
    public void ContinueStart()
	{
        SceneChangeManager.Instance.SceneChange("");
	}
    //-------------------------------------------------------------------------------
}
