﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class EventMessage : SingletonClass<EventMessage>
{
	/// <summary>
	/// 反映するテキスト
	/// </summary>
	[SerializeField] Text messageText = null;
	/// <summary>
	/// 反映するウィンドウ
	/// </summary>
	[SerializeField] Canvas textCanvas = null;
	/// <summary>
	/// イベント開始時間
	/// </summary>
	float eventStartTime;
	/// <summary>
	/// メッセージが消えるまでの時間
	/// </summary>
	[Header("メッセージが消えるまでの時間")]
	[SerializeField] float eventMessageTime = 1.0f;
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メッセージを表示する
	/// </summary>
	/// <param name="message_"></param>
	public void MessageActive(string message_)
	{
		TextActive(true);

		this.messageText.text = message_;

		//開始時間記録
		this.eventStartTime = Time.time;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// テキストの表示・非表示
	/// </summary>
	/// <param name="isActive">有効にするか</param>
	void TextActive(bool isActive)
	{
		this.textCanvas.gameObject.SetActive(isActive);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メッセージ表示終了条件設定
	/// </summary>
	public IsAction MessageAction(string data)
	{
		IsAction action = (()=>true);
		//終了条件分岐
		switch (data)
		{
			//アクションボタンが押されたか
			case "Action":		action = (() => InputManager.Instance.input.ActionKeyDown()); break;
			//横入力があったか
			case "Horizontal":	action = (() => InputManager.Instance.input.AxisHorizontal() != 0.0f); break;
			//ジャンプ入力があったか
			case "Jump":		action = (() => InputManager.Instance.input.JumpKeyDown()); break;
			//時間経過か
			case "Time":		action = (() => CheckMessageTime()); break;
			//入力がない場合、時間経過 or アクションボタンで次へ
			default:			action = (() => InputManager.Instance.input.ActionKeyDown() || CheckMessageTime()); break;
		}

		return action;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メッセージイベント終了時の処理
	/// </summary>
	/// <returns></returns>
	public void MessageEnd()
	{
		//終了時の処理
		TextActive(false);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 表示してから時間が経過したか
	/// </summary>
	/// <returns></returns>
	bool CheckMessageTime()
	{
		return Time.time - this.eventStartTime >= this.eventMessageTime;
	}
	//-------------------------------------------------------------------------------

}
