﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 実行されたか返す
/// </summary>
/// <returns></returns>
public delegate bool IsAction();
//-------------------------------------------------------------------------------
/// <summary>
/// イベントシステム統括
/// </summary>
public class EventManager : SingletonClass<EventManager>
{
	/// <summary>
	/// イベント状態か
	/// </summary>
	public  bool isEvent;

	/// <summary>
	/// 登録するイベント名
	/// </summary>
	public string[] eventDataName;
	//-------------------------------------------------------------------------------
	/// <summary>
	/// イベント処理確認
	/// </summary>
	/// <param name="eventName">イベント名</param>
	public void EventStart(string eventName)
	{
		//イベントリストをチェック
		bool isExist = false;
		foreach (string iName in this.eventDataName)
		{
			if(iName == eventName) { isExist = true; break; }
		}
		//イベント名がなければ処理終了
		if (isExist == false) { Debug.LogError("該当するイベント処理がありませんでした：" + eventName); return; }

		//イベントスタート
		StartCoroutine(EventEngine(eventName));

	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 非同期イベントスタート
	/// </summary>
	/// <param name="data">実行するイベントテキスト</param>
	/// <returns></returns>
	IEnumerator EventEngine(string eventName)
	{
		//イベントファイル読み込み
		List<string> data = FileLoad.DataLoadResource(eventName);

		//イベント状態をONに
		isEvent = true;


		//１行目のメッセージによってゲームへの影響を確認する
		int n = 0;
		if (data[n] == "") 
		{
			//プレイヤー操作：OFF

			//時間カウント：OFF

		}

		//２行目以降はループ
		for(n = 1; n < data.Count; n++)
		{
			IsAction action = (()=>true);
			//先頭要素によって処理変更
			switch(data[n].Split(',')[0])
			{
				//メッセージ表示
				case "msg":
					EventMessage.Instance.MessageActive(data[n].Split(',')[1]);
					//終了条件
					action = EventMessage.Instance.MessageAction(data[n].Split(',')[2]);
					break;
				//シーン切り替え
				case "scene":	break;
				//イベント終了
				case "end":		break;
			}

			//終了条件が満たされるまで待機
			yield return new WaitUntil(() => action());
			yield return null;
		}


		//イベント終了
		isEvent = false;

		//終了処理
		EventMessage.Instance.MessageEnd();	//メッセージ終了

		yield break;
	}
	//-------------------------------------------------------------------------------
}
