﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// アイテム管理
/// </summary>
public class ItemManager : SingletonClass<ItemManager>
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// アイテムの種類
	/// </summary>
	public enum Category
	{
		NONE = -1,
		/// <summary>
		/// 植物
		/// </summary>
		PLANT = 0,
		/// <summary>
		/// 薬品
		/// </summary>
		DLUG = 1,
		/// <summary>
		/// 小道具
		/// </summary>
		TOOL = 2,
		/// <summary>
		/// 書物
		/// </summary>
		BOOK = 3,
		/// <summary>
		/// 武器
		/// </summary>
		WEAPON = 4,
		/// <summary>
		/// 防具
		/// </summary>
		ARMOR = 5,
		/// <summary>
		/// 宝石
		/// </summary>
		JEWEL = 6,
		/// <summary>
		/// 指輪
		/// </summary>
		RING = 7,
		/// <summary>
		/// 食物
		/// </summary>
		FOOD = 8,
	}
	//-------------------------------------------------------------------------------
	//アイテムリスト
	public List<Item> itemList;
	//アイテム画像リスト
	public Sprite[] itemSprites;
	//ステージごとの取得可能なアイテムリスト
	public Dictionary<string,Category[]> stageItemCategory;
	//-------------------------------------------------------------------------------
	protected override void AwakeInitialize()
	{
		DontDestroyOnLoad(gameObject);

		//アイテムデータの読み込み
		this.itemList = new List<Item>();
		Instance.ItemDataLoad();	

		//アイテム画像の読み込み
		this.itemSprites = new Sprite[this.itemList.Count];
		Instance.ItemSpriteLoad();

		//ステージごとの取得可能なアイテムリスト設定
		this.stageItemCategory = new Dictionary<string, Category[]>();
		//シーン名で保存
		this.stageItemCategory["ActionForestMap"] = new Category[] { Category.PLANT, Category.DLUG ,Category.FOOD};
	}
	//-------------------------------------------------------------------------------
	public string GetItemName(Category category)
	{
		string sName = "";
		switch (category)
		{
			case Category.PLANT:	sName = "植物"; break;
			case Category.DLUG:		sName = "薬品"; break;
			case Category.TOOL:		sName = "小道具"; break;
			case Category.BOOK:		sName = "書物"; break;
			case Category.WEAPON:	sName = "武器"; break;
			case Category.ARMOR:	sName = "防具"; break;
			case Category.JEWEL:	sName = "宝石"; break;
			case Category.RING:		sName = "指輪"; break;
			case Category.FOOD:		sName = "食物"; break;
		}
		return sName;

	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// アイテムデータの読み込み・反映
	/// </summary>
	void ItemDataLoad()
	{
		//テキストフェイルからアイテムデータを読み込む
		List<string> itemData = FileLoad.DataLoadResource("item");

		//要素分繰り返す
		for (int i = 0; i < itemData.Count; i++)
		{
			//文字列を分割してアイテムを作成
			string line = itemData[i];

			//文字列から作成するアイテムのカテゴリを決定
			Category itemCategory = Category.NONE;
			switch(line.Split(',')[2])
			{
				case "植物":	itemCategory = Category.PLANT;	break;
				case "薬品":	itemCategory = Category.DLUG;	break;
				case "小道具":	itemCategory = Category.TOOL;	break;
				case "書物":	itemCategory = Category.BOOK;	break;
				case "武器":	itemCategory = Category.WEAPON; break;
				case "防具":	itemCategory = Category.ARMOR;	break;
				case "宝石":	itemCategory = Category.JEWEL;	break;
				case "指輪":	itemCategory = Category.RING;	break;
				case "食物":	itemCategory = Category.FOOD;	break;
			}

			//アイテム作成
			Item item = new Item
				(
					int.Parse(line.Split(',')[0]),	//アイテム番号
					line.Split(',')[1],				//アイテム名
					itemCategory,					//アイテムカテゴリ
					int.Parse(line.Split(',')[3])	//値段
				);

			//アイテムリストに追加
			this.itemList.Add(item);
		}
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// アイテム画像の読み込み・反映
	/// </summary>
	void ItemSpriteLoad()
	{
		//要素分繰り返す
		for(int i =0; i < this.itemSprites.Length;i++)
		{
			//読み込んで反映
			this.itemSprites[i] = FileLoad.SpriteDataLoadResource("Item/item" + (i + 1).ToString());
		}
	}
}
