﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Timer : MonoBehaviour
{
    //空objectにアタッチしてください(clockManager)

    [Header("時計針")]
    [SerializeField] private GameObject needle = null;
    [Header("制限時間")]
    [SerializeField] private int limit = 0;
    [Header("針更新速度")]
    [SerializeField] private float updateSpeed = 0.0f;

    private float time;
    float count;
    void Start()
    {
        needle.transform.eulerAngles = new Vector3(0, 0, 0);
        time = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        time += Time.deltaTime;
        count += Time.deltaTime;
        if (count >= updateSpeed)
        {
            needle.transform.eulerAngles = new Vector3(0, 0, -time / limit * 360);
            count = 0;
        }

        if (Timecount() >= 1f)
        {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#elif UNITY_STANDALONE
             UnityEngine.Application.Quit();
#endif
        }
    }
    public float Timecount()
    {
        return time/ limit;
    }
}
