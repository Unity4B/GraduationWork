﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// 音源再生基礎クラス
/// </summary>
public abstract class SoundController<T> : SingletonClass<T> where T: SingletonClass<T>
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// オーディオコンポーネント
	/// </summary>
	[SerializeField] protected AudioSource audios = null;
	//-------------------------------------------------------------------------------
	/// <summary>
	/// BGMを再生する
	/// </summary>
	/// <param name="sName">再生したい音源名</param>
	public abstract void Play(string sName);
	/// <summary>
	/// BGMを再生する
	/// </summary>
	/// <param name="sName">再生したい音源名</param>
	/// <param name="volume">ボリューム 0.0f ～ 1.0f</param>
	public abstract void Play(string sName,float volume);
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 音量を設定する
	/// </summary>
	/// <param name="volume">ボリューム 0.0f ～ 1.0f</param>
	public abstract void SetVolume(float volume);
	//-------------------------------------------------------------------------------
}
