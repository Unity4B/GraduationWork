﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// リザルトシーン管理
/// </summary>
public class ResultManager : MonoBehaviour
{
	void Awake()
	{
		//BGM
		//BGMController.Instance.Play("ResultBGM");

		//イベント
		EventManager.Instance.EventStart("RESULT");
	}
}
