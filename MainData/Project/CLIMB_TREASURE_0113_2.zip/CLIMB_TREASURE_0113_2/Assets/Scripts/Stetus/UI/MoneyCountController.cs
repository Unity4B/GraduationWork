﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MoneyCountController : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 使用するText
	/// </summary>
	[SerializeField] Text moneyText = null;
	/// <summary>
	/// 前に表示した金額
	/// </summary>
	int preMoney;
	//-------------------------------------------------------------------------------
	void Start()
	{
		this.moneyText.text = PlayData.Instance.money.ToString() + "G";
	}
	//-------------------------------------------------------------------------------
	void Update()
	{
		//金額が変わっていたら更新
		if(this.preMoney != PlayData.Instance.money)
		{
			this.moneyText.text = PlayData.Instance.money.ToString() + "G";

			this.preMoney = PlayData.Instance.money;
		}
	}
	//-------------------------------------------------------------------------------
}
