﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// セーブ・ロード
/// </summary>
public class DataManager : SingletonClass<DataManager>
{
	/// <summary>
	/// セーブデータ名
	/// </summary>
	[Header("セーブデータ名")]
	[SerializeField] string dataName = "";
	//-------------------------------------------------------------------------------
	protected override void AwakeInitialize()
	{
		DontDestroyOnLoad(gameObject);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 現在のデータをセーブ
	/// </summary>
	public void Save()
	{
		SaveData saveClass = new SaveData();
		saveClass.Save(this.dataName);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 保存してあったデータをロード
	/// </summary>
	public void Load()
	{
		//データがあるかチェック
		if(CheckData())
		{
			//ロード
			LoadData loadClass = new LoadData();
			loadClass.Load(this.dataName);
		}
		else
		{
			//エラー処理
			Debug.LogWarning("保存されているセーブデータはありません：" + this.dataName);
		}
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 保存したデータがあるかチェック
	/// </summary>
	/// <returns></returns>
	public bool CheckData()
	{
		return PlayerPrefs.HasKey(this.dataName);
	}
	//-------------------------------------------------------------------------------
}
