﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------------------------------------
/// <summary>
/// アイテム情報の表記
/// </summary>
public class ItemInfoController : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 店関連の管理クラス
	/// </summary>
	[SerializeField] protected StoreManager sManager = null;
	/// <summary>
	/// 表示するアイテム
	/// </summary>
	protected Item item;
	/// <summary>
	/// アイテム番号
	/// </summary>
	public int itemNum;
	/// <summary>
	/// アイテム画像表記イメージ
	/// </summary>
	[SerializeField] protected Image iImage = default;
	/// <summary>
	/// アイテム名表記テキスト
	/// </summary>
	[SerializeField] protected Text iNameText = default;
	/// <summary>
	/// 値段表記テキスト
	/// </summary>
	[SerializeField] protected Text priceText = default;
	/// <summary>
	/// アイテムの買取値段
	/// </summary>
	public int itemPrice;
	//-------------------------------------------------------------------------------
	/// <summary>
	/// UIの更新
	/// </summary>
	public virtual void UIUpdate()
	{
		//アイテム無しなら処理せず
		if (this.itemNum <= 0) { return; }

		//表示したいアイテムの情報を受け取る
		this.item = ItemManager.Instance.itemList.FirstOrDefault(value => value.Num == this.itemNum);

		//オブジェクトに反映
		this.iImage.sprite = ItemManager.Instance.itemSprites[this.item.Num - 1];
		this.iNameText.text = this.item.IName;
	}
	//-------------------------------------------------------------------------------
}
