﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// 背景操作
/// </summary>
public class BackImageController : MonoBehaviour
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 移動速度
    /// </summary>
    [SerializeField] float moveSpeed = 1.0f;
    /// <summary>
    /// リスタート位置
    /// </summary>
    [SerializeField] float restartPosX = 0.0f;
    /// <summary>
    /// 終了位置
    /// </summary>
    [SerializeField] float endPosX = 0.0f;
    //-------------------------------------------------------------------------------
    // Update is called once per frame
    void Update()
    {
        //時間が経過していれば初期からスタート
        if(transform.localPosition.x < this.endPosX) 
        {
            transform.localPosition = new Vector2(this.restartPosX, transform.localPosition.y); 
        }

        //移動
        transform.Translate(new Vector2(-this.moveSpeed * Time.deltaTime, 0.0f));

    }
    //-------------------------------------------------------------------------------
}
