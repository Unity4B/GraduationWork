﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// ステージ選択管理
/// </summary>
public class StageSelectManager : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 確認クラス
	/// </summary>
	[SerializeField] ConfirmationController confirmationClass = null;
	/// <summary>
	/// ステージのボタン選択クラス
	/// </summary>
	[SerializeField] ButtonSelecter stageSelectClass = null;
	/// <summary>
	/// アイテム確認
	/// </summary>
	[SerializeField] GameObject itemConfir = null;
	//-------------------------------------------------------------------------------
	void Awake()
	{
		//日数経過
		PlayData.Instance.dayCnt++;

		//チュートリアルイベント
		EventManager.Instance.EventStart("NEW_STAGESELECT_IN");

	}
	//-------------------------------------------------------------------------------
	private void Start()
	{
		//BGMストップ
		BGMController.Instance.Stop();
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// ステージチェンジをセット
	/// </summary>
	/// <param name="sName">次のシーン名</param>
	public void StageSceneChange(string sName)
	{
		this.confirmationClass.ResetAction();
		this.confirmationClass.SetAction(() => SceneChangeManager.Instance.SceneChange(sName));
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// アイテム確認ウィンドウ表示
	/// </summary>
	/// <param name="isActive">有効か</param>
	public void ItemConfirmationActive(bool isActive)
	{
		this.stageSelectClass.enabled = !isActive;
		this.itemConfir.SetActive(isActive);
	}
	//-------------------------------------------------------------------------------

}
