﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// 自主帰還の選択ができるようになる機能
/// </summary>
public class VoluntaryReturn : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// プレイヤー操作クラス
	/// </summary>
	[SerializeField] PlayerMove playerClass = null;
	//-------------------------------------------------------------------------------
	//接触時に判定
	private void OnTriggerEnter2D(Collider2D col)
	{
		//プレイヤーと接触時 かつ シーン切り替え終了後、機能する
		if(col.gameObject.CompareTag("Player") && SceneChangeManager.Instance.IsNowChange == false)
		{
			this.playerClass.PlayerActive(false);

			//自主帰還するかの確認UIを表示
			ConfirmationObjController.Instance.Active
			(
				() => ActionManager.Instance.VoluntaryReturn(),         //アクションパート終了コマンド
				() => this.playerClass.PlayerActive(true),				//プレイヤー操作可能に
				"帰還しますか？\n（使用したアイテムの効果は失われます）"  //メッセージ
			);
		}
	}
	//-------------------------------------------------------------------------------
}
