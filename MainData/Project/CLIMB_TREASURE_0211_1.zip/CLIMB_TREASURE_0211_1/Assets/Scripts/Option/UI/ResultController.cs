﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------------------------------------
/// <summary>
/// リザルト操作
/// </summary>
public class ResultController : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 使用するText
	/// </summary>
	[SerializeField] Text messageText = null;
	/// <summary>
	/// ボタン選択表示をするオブジェクト
	/// </summary>
	[SerializeField] GameObject buttonObj = null;
	//-------------------------------------------------------------------------------
	void Start()
	{
		StartCoroutine(ResultCoroutine());
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// リザルト表示
	/// </summary>
	/// <returns></returns>
	IEnumerator ResultCoroutine()
	{
		//順番にメッセージを表示していく
		string message = "";

		this.messageText.text = message;

		//1秒待つ
		yield return new WaitForSeconds(1.0f);

		//探索日数
		message += "探索日数：" + PlayData.Instance.dayCnt.ToString() + "日目\n\n";
		//SE
		SEController.Instance.Play("system_select", 0.7f);

		this.messageText.text = message;
		//1秒待つ
		yield return new WaitForSeconds(1.0f);

		//取得アイテム数
		int itemCnt = 0;
		//取得済みのアイテム数を数える
		foreach(bool isGet in PlayData.Instance.isGotItems)
		{
			if (isGet) { itemCnt++; }
		}

		message += "取得アイテム数：" +
			 itemCnt.ToString() + 
			"/" + ItemManager.Instance.itemList.Count.ToString() + "\n\n";
		//SE
		SEController.Instance.Play("system_select", 0.7f);

		this.messageText.text = message;
		//1秒待つ
		yield return new WaitForSeconds(1.0f);

		//所持金表示
		message += "所持金：" + PlayData.Instance.money.ToString() + "G\n\n";
		//SE
		SEController.Instance.Play("system_select", 1.0f);

		this.messageText.text = message;
		//1秒待つ
		yield return new WaitForSeconds(1.0f);

		//メッセージ表示
		message += "ここまで遊んでいただきありがとうございました。\nこの先も続けて遊ぶことはできます。\n全マップ登頂、アイテムコンプリートなど\n目指していただけると幸いです。";

		this.messageText.text = message;
		//ボタン表示
		this.buttonObj.SetActive(true);

		yield break;
	}
	//-------------------------------------------------------------------------------
	public void SceneChange(string sName)
	{
		SceneChangeManager.Instance.SceneChange(sName);
	}
	//-------------------------------------------------------------------------------
}
