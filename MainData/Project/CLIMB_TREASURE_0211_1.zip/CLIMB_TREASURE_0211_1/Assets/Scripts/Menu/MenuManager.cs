﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// メニュー管理
/// </summary>
public class MenuManager : SingletonClass<MenuManager>
{
    
    //-------------------------------------------------------------------------------
    /// <summary>
    /// メニューを開いているか
    /// </summary>
    public bool isMenuActive;
    /// <summary>
    /// プレイヤークラス
    /// </summary>
    [SerializeField] PlayerMove playerClass = null;
    /// <summary>
    /// 使用するアニメーター
    /// </summary>
    [SerializeField] Animator anim = null;
    /// <summary>
    /// アニメーション中か
    /// </summary>
    bool isAnimation;
    //-------------------------------------------------------------------------------
    void Start()
	{
        MenuController.Instance.gameObject.SetActive(false);
        this.isMenuActive = false;
        this.isAnimation = false;
    }
	//-------------------------------------------------------------------------------
	void Update()
    {
        //メニューアクティブ・非アクティブ化
        if (InputManager.Instance.input.MenuKeyDown()&& SceneChangeManager.Instance.IsNowChange == false)
        {
            MenuAnimation(!this.isMenuActive);
        }
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// メニューアクティブ・非アクティブアニメーション
    /// </summary>
    /// <param name="isActive">アクティブにするか</param>
    public void MenuAnimation(bool isActive)
	{
        //アニメーション中は処理せず
		if (this.isAnimation) { return; }

        //アクティブ
		if (isActive) 
        {
            MenuActive(isActive);
            this.anim.SetTrigger("Active"); 
            //SE
            SEController.Instance.Play("menu_on", 1.0f);        
        }
        //非アクティブ
		else 
        {
            this.anim.SetTrigger("InActive"); 
            //SE
            SEController.Instance.Play("menu_off", 1.0f);
        }

        this.isAnimation = true;
	}
    //-------------------------------------------------------------------------------
    /// <summary>
    /// メニューアクティブ・非アクティブ
    /// </summary>
    /// <param name="isActive">アクティブにするか</param>
    public void MenuActive(bool isActive)
	{
        MenuController.Instance.gameObject.SetActive(isActive);
        //メニュー状態更新
        this.isMenuActive = isActive;

		//イベントでプレイヤーを止めている場合、プレイヤーの動きは変えない
		if (EventObject.Instance.IsPlayerStop) { return; }
        //プレイヤー操作
        if(this.playerClass != null) { this.playerClass.PlayerActive(!isActive);}
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// アニメーション処理が終わったことにする処理
    /// </summary>
    public void AnimationEnd()
	{
        this.isAnimation = false;
	}
    //-------------------------------------------------------------------------------
}
