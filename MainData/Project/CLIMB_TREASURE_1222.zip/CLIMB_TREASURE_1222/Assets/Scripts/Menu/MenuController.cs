﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// メニュー関連操作
/// </summary>
public class MenuController : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// ボタンスクリプト（現在選択中のオブジェクト設定）
	/// </summary>
	[SerializeField] ButtonSelecter buttonClass = null;
	/// <summary>
	/// メニュー項目ごとのオブジェクト
	/// </summary>
	[Header("メニュー項目ごとのオブジェクト")]
	[SerializeField] GameObject[] menuObj = null;
	/// <summary>
	/// 現在選択中のメニューオブジェクト番号
	/// </summary>
	int nowButtonNum;
	/// <summary>
	/// 選択機能が有効か
	/// </summary>
	bool isSelectActive;
	//-------------------------------------------------------------------------------
	void Start()
	{
		this.isSelectActive = true;	
	}

	void Update()
	{
		//選択機能によって処理変更
		if (this.isSelectActive)
		{
			//選択、決定でメニューオブジェクトアクティブ
			if (InputManager.Instance.input.ActionKeyDown())
			{
				//現在選択中のボタンを受け取る
				this.nowButtonNum = this.buttonClass.GetNowButton();

				//メニューオブジェクトをアクティブ
				MenuObjActive(nowButtonNum, true);

				//ボタン選択機能オフ
				this.buttonClass.enabled = false;

				//選択機能オフ
				this.isSelectActive = false;
			}
		}
		else
		{
			//キャンセルでメニューオブジェクト非アクティブ
			if (InputManager.Instance.input.CanselKeyDown())
			{
				//ボタン選択機能オン
				this.buttonClass.enabled = true;

				//メニューオブジェクトをアクティブ
				MenuObjActive(nowButtonNum, false);

				//選択機能オン
				this.isSelectActive = true;
			}
		}
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メニューオブジェクトの有効・無効化
	/// </summary>
	/// <param name="num">対象の配列番号</param>
	/// <param name="isActive">有効にするか</param>
	void MenuObjActive(int num,bool isActive)
	{
		//番号が配列範囲外なら処理中断
		if(num < 0  || this.menuObj.Length <= num) { Debug.LogWarning("MenuObjの配列外を指定しています。：" + num); return; }

		this.menuObj[num].SetActive(isActive);
	}
	//-------------------------------------------------------------------------------
}
