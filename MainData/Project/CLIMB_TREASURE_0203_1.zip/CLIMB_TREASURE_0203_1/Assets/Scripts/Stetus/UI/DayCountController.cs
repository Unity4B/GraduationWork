﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------------------------------------
/// <summary>
/// 日数を表示
/// </summary>
public class DayCountController : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 使用するText
	/// </summary>
	[SerializeField] Text dayText = null;
	//-------------------------------------------------------------------------------
	void Start()
	{
		this.dayText.text = PlayData.Instance.dayCnt.ToString() + "日目";
	}
	//-------------------------------------------------------------------------------

}
