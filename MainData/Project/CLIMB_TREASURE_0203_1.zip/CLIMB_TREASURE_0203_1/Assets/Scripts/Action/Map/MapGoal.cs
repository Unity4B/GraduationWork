﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 接触時にゴール判定をする機能
/// </summary>
public class MapGoal : MonoBehaviour
{
	private void OnTriggerEnter2D(Collider2D col)
	{
		//プレイヤーと接触した場合
		if(col.gameObject.CompareTag("Player"))
		{
			//ゴールイベントスタート
			GoalEvent();
		}
	}

	/// <summary>
	/// ゴール時のイベント処理
	/// </summary>
	public virtual void GoalEvent()
	{
		EventManager.Instance.EventStart("MAP_GOAL");
	}
}
