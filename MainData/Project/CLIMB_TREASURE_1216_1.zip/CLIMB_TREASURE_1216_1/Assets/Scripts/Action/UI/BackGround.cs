﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackGround : MonoBehaviour
{
    [Header("奥背景")]
    [SerializeField] GameObject[] end_background = null;
    [SerializeField] float end_dif;

    [Header("中間背景")]
    [SerializeField] GameObject[] middle_background = null;
    [SerializeField] float middle_dif;

    [Header("最前背景")]
    [SerializeField] GameObject[] first_background = null;
    [SerializeField] float first_dif;

    [SerializeField] GameObject player = null;

    private float dif;
    private float std_value;

    void Awake()
    {
        std_value = player.transform.position.x;
        for (int v = 0; v < end_background.Length; v++)
        {
            end_background[v].transform.position = new Vector3(0, 0, 10);
        }
        for (int v = 0; v < middle_background.Length; v++)
        {
            middle_background[v].transform.position = new Vector3(0, 0, 10);
        }
        for (int v = 0; v < first_background.Length; v++)
        {
            first_background[v].transform.position = new Vector3(0, 0, 10);
        }
    }

    void FixedUpdate()
    {
        dif = std_value - player.transform.position.x;
       
        background();
    }
    void background()
    {
        

        end_dif = ((0.0f - player.transform.position.x) * Time.deltaTime);
        middle_dif = ((0.0f - player.transform.position.x) * 3.0f * Time.deltaTime);
        first_dif = (0.0f - player.transform.position.x) * 7.0f * Time.deltaTime;
        //--------------------------------
        if (Mathf.Abs(dif) >= 1.0f)
        {
            for (int v= 0; v < end_background.Length;v++)
            {
                end_background[v].transform.position = new Vector3(end_dif, 0, 10);
            }
            for (int v= 0; v < middle_background.Length; v++)
            {
                middle_background[v].transform.position = new Vector3(middle_dif, 0, 10);
            }
            for (int v= 0; v < first_background.Length; v++)
            {
                    first_background[v].transform.position = new Vector3(first_dif, 0, 10);
            }
            std_value = player.transform.position.x;
        }
        else
        {
            end_dif = 0.0f;
            middle_dif = 0.0f;
            first_dif = 0.0f;
        }
    }
}
