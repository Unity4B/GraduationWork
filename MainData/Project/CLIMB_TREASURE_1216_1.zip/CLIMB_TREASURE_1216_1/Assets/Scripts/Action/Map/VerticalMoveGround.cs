﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VerticalMoveGround : GroundBase
{
    protected override void PlayerStayCollision(Collision2D collision)
    {
        base.PlayerStayCollision(collision);
    }

    protected override void PlayerExitCollision(Collision2D collision)
    {
        base.PlayerExitCollision(collision);
    }
}
