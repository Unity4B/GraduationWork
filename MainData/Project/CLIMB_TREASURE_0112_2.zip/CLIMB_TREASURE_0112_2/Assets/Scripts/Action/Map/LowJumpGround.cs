﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// ジャンプ力が下がる床
/// </summary>
public class LowJumpGround : GroundBase
{
    [SerializeField] float lowjumpForce = 10f;  //下がったジャンプ力
    [SerializeField] float preJumpForce = 15f;  //戻ったジャンプ力

    protected override void PlayerStayCollision(Collision2D collision)
    {
        base.PlayerStayCollision(collision);
        collision.transform.GetComponent<PlayerMove>().jumpForce = lowjumpForce;
    }

    protected override void PlayerExitCollision(Collision2D collision)
    {
        collision.transform.GetComponent<PlayerMove>().jumpForce = preJumpForce;
        base.PlayerExitCollision(collision);
    }
}
