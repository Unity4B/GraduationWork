﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------------------------------------
/// <summary>
/// キー画像表示
/// </summary>
public class KeyTypeController : MonoBehaviour
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 初期表示するキー
    /// </summary>
    [SerializeField] KEYTYPE kType = KEYTYPE.NONE;
    /// <summary>
    /// 使用するImage
    /// </summary>
    [SerializeField] Image kImage = null;
	//-------------------------------------------------------------------------------
	void Awake()
	{
		SetKeySprite(this.kType);	
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// キー画像を表示
	/// </summary>
	/// <param name="kType">表示するキー</param>
	public void SetKeySprite(KEYTYPE kType_)
	{
        this.kImage.sprite = KeyTypeManager.Instance.GetKeySprite(kType_);
	}
    //-------------------------------------------------------------------------------
}
