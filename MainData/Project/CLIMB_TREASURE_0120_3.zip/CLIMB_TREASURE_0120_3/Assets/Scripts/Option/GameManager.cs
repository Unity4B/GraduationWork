﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// ゲーム全体の統括
/// </summary>
public class GameManager : SingletonClass<GameManager>
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// クリア必要金額
	/// </summary>
	[Header("クリア条件")]
	[SerializeField] int clearMoney = 1000000;
	//-------------------------------------------------------------------------------
	protected override void AwakeInitialize()
	{
		DontDestroyOnLoad(gameObject);
	}
	//-------------------------------------------------------------------------------
	void Update()
	{
		if (InputManager.Instance.input.ExitKeyDown())
		{
#if UNITY_EDITOR
			UnityEditor.EditorApplication.isPlaying = false;
#elif UNITY_STANDALONE
			UnityEngine.Application.Quit();
#endif
		}

	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// ゲームクリア条件を満たしているか
	/// </summary>
	/// <returns></returns>
	public bool CheckGameClear()
	{
		//クリア金額に達しているか
		if(PlayData.Instance.money < this.clearMoney) { return false; }
		//すでにクリアしているか
		if (PlayData.Instance.eventData.CheckEventFlag("NEW_CLEAR")) { return false; }

		return true;
	}
	//-------------------------------------------------------------------------------
}
