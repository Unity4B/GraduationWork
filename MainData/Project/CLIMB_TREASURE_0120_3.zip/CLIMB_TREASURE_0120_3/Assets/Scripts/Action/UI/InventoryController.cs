﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------------------------------------
/// <summary>
/// インベントリ（アイテム）の表示
/// </summary>
public class InventoryController : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 前に変更された所持アイテムの配列
	/// </summary>
	int[] preItemNums;
	/// <summary>
	/// 反映するImage
	/// </summary>
	[SerializeField] Image[] itemImages = null;
	/// <summary>
	/// アイテムがない場合に表示する画像
	/// </summary>
	[SerializeField] Sprite defaultSprite = null;
	//-------------------------------------------------------------------------------
	void Start()
	{
		ItemNumUpdate();
		UIUpdate();
	}
	//-------------------------------------------------------------------------------
	void Update()
	{
		//所持アイテムが変わっていたら更新
		if (CheckItems()) 
		{
			UIUpdate();
			ItemNumUpdate();
		}
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// アイテム番号更新
	/// </summary>
	void ItemNumUpdate()
	{
		this.preItemNums = new int[PlayData.Instance.itemNums.Length];
		for (int i = 0; i < PlayData.Instance.itemNums.Length; i++)
		{
			this.preItemNums[i] = PlayData.Instance.itemNums[i];
		}
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// UIの更新
	/// </summary>
	void UIUpdate()
	{
		//インベントリの分だけループ
		for(int i = 0; i < this.itemImages.Length; i++)
		{
			int num = PlayData.Instance.itemNums[i];

			//アイテムがない場合
			if(num <= 0) { this.itemImages[i].sprite = this.defaultSprite; return; }

			//プレイデータに格納されたアイテム番号に合わせて画像変更
			this.itemImages[i].sprite = ItemManager.Instance.itemSprites[num - 1];
		}
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// アイテムが変更されたかチェック
	/// </summary>
	/// <returns></returns>
	bool CheckItems()
	{
		bool isChenge = false;

		for(int i = 0; i < this.preItemNums.Length; i++)
		{
			//違うアイテムがあった場合、TRUE
			if (this.preItemNums[i] != PlayData.Instance.itemNums[i]) 
			{ isChenge = true; break; }
		}

		return isChenge;
	}
	//-------------------------------------------------------------------------------
}
