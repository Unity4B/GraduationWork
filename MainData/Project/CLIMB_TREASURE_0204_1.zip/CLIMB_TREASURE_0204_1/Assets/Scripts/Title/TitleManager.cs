﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// タイトル管理
/// </summary>
public class TitleManager : SingletonClass<TitleManager>
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// タイトルメニューに使用しているButtonSelecter
    /// </summary>
    [Header("タイトルメニューに使用しているButtonSelecter")]
    [SerializeField] ButtonSelecter buttonClass = null;
	//-------------------------------------------------------------------------------
	void Start()
	{
        //BGM再生
        BGMController.Instance.Play("TitleBGM", 0.1f, FadeType.In, 3.0f);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 新しくスタート
	/// </summary>
	public void NewGameStart()
	{
        //ボタン選択オフ
        this.buttonClass.enabled = false;

        //アクションパートへ
        SceneChangeManager.Instance.SceneChange("ActionTutorialMap");
	}
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 続きから
    /// </summary>
    public void ContinueStart()
	{
        //保存データがあるかチェック
		if (!DataManager.Instance.CheckData()) 
        {
            //ない場合、UI表示＆処理終了
            AttentionController.Instance.ActiveAttention("保存されているデータがありません。");

            return; 
        }
        //ボタン選択オフ
        this.buttonClass.enabled = false;

        //データをロード
        DataManager.Instance.Load();

        //セールパートへ
        SceneChangeManager.Instance.SceneChange("SaleScene");
	}
    //-------------------------------------------------------------------------------
}
