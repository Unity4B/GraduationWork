﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CatalogSwitch : MonoBehaviour
{
    [SerializeField] GameObject catalog = null;
    
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            this.catalog.SetActive(!this.catalog.activeSelf);
            catalog.GetComponent<Catalog>().CatalogUpdate();
        }
    }
}
