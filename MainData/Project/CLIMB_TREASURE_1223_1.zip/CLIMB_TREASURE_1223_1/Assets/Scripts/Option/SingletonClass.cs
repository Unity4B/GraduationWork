﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

//-------------------------------------------------------------------------------
/// <summary>
/// シングルトンクラス
/// </summary>
public abstract class SingletonClass<T> : MonoBehaviour where T : MonoBehaviour
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 生成されたクラス
    /// </summary>
    private static T instance;
    //-------------------------------------------------------------------------------
    //プロパティ
    /// <summary>
    /// 生成されたクラス
    /// </summary>
    public static T Instance
    {
        //戻り値
        get
        {
            if (instance == null)
            {
                Type t = typeof(T);

                instance = (T)FindObjectOfType(t);

                if (instance == null)
                {
                    Debug.LogError(t.ToString() + "をアタッチしているGameObjectはありません");
                }
            }

            return instance;
        }
    }
    //-------------------------------------------------------------------------------
    void Awake()
    {
        //他のGameObjectにアタッチされているか調べる
        //アタッチされている場合
        if(CheckInstance())
        {
            //アタッチされているのが自分以外なら、処理終了
            if(instance != this) 
            { 
                Destroy(gameObject);
                return;
            }

        }
        //アタッチされていない場合
        else
        {
            //生成
            instance = this as T;
        }

        //汎用型の初期化
        AwakeInitialize();
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 汎用型の初期化関数
    /// </summary>
    virtual protected void AwakeInitialize()
	{
	}
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 他のGameObjectにアタッチされているか調べる
    /// </summary>
    /// <returns></returns>
    protected bool CheckInstance()
    {
        if (instance == null)   { return false; }
        else                    { return true; }
    }
    //-------------------------------------------------------------------------------
}
