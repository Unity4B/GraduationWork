﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// アイテムクラス
/// </summary>
public class Item
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// アイテム番号
	/// </summary>
	int num;
	/// <summary>
	/// アイテム名
	/// </summary>
	string iName;
	/// <summary>
	/// カテゴリ名
	/// </summary>
	ItemManager.Category iCategory;
	/// <summary>
	/// 値段
	/// </summary>
	int price;
	//-------------------------------------------------------------------------------
	//プロパティ
	/// <summary>
	/// アイテム番号
	/// </summary>
	public int Num
	{
		private set { this.num = value; }
		get { return this.num; }
	}
	/// <summary>
	/// アイテム名
	/// </summary>
	public string IName
	{
		private set { this.iName = value; }
		get	{ return this.iName; }
	}
	/// <summary>
	/// カテゴリ名
	/// </summary>
	public ItemManager.Category ICategory
	{
		private set { this.iCategory = value; }
		get { return this.iCategory; }
	}
	/// <summary>
	/// 値段
	/// </summary>
	public int Price
	{
		private set { this.price = value; }
		get { return this.price; }
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// コンストラクタ
	/// </summary>
	/// <param name="num_">番号</param>
	/// <param name="iName_">アイテム名</param>
	/// <param name="category_">カテゴリ名</param>
	/// <param name="price_">値段</param>
	public Item(int num_, string iName_, ItemManager.Category category_, int price_)
	{
		Num = num_;
		IName = iName_;
		ICategory = category_;
		Price = price_;
	}
	//-------------------------------------------------------------------------------
}
