﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Catalog : SingletonClass<Catalog>
{
    /// <summary>
    /// アイテムデータを表示するプレファブ
    /// </summary>
    [SerializeField] GameObject itemDataPrefab = null;
    /// <summary>
    /// アイテムリストの親とするオブジェクト
    /// </summary>
    [SerializeField] GameObject ItemListParent = null;
    /// <summary>
    /// スクロール速度（初期設定：10）
    /// </summary>
    public float ScrollSpeed = 10;
    /// <summary>
    /// アイテムデータ配列
    /// </summary>
    List<GameObject> Datas = new List<GameObject>();

	protected override void AwakeInitialize()
	{
        DontDestroyOnLoad(gameObject.transform.root);
    }

    // Start is called before the first frame update
    void Start()
    {
        //アイテムデータ確保　50個分
        for (int i = 0; i < 50; i++) 
        {
            GameObject data = Instantiate(itemDataPrefab);
            //子オブジェクト化
            data.transform.SetParent(ItemListParent.transform);
            //位置調整
            data.transform.localPosition = new Vector2(-440, -i * 120 - 50);
            //名前を番号化
            data.name = itemDataPrefab.name + (i + 1);
            //データ割り振り
            if (PlayData.Instance.isGotItems[i])
            {
                CatalogItemInfoController item = data.GetComponent<CatalogItemInfoController>();
                item.itemNum = i + 1;
                item.UIUpdate();
            }
            //データ配列に追加
            this.Datas.Add(data);
        }
        this.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        //前フレームのポジションを保持
        //Vector3 prePos = ItemListParent.gameObject.transform.position;
        //上下キーでスクロール
        if (InputManager.Instance.input.UpKeyOn()) 
            ItemListParent.gameObject.transform.Translate(0, -ScrollSpeed, 0);
        if (InputManager.Instance.input.DownKeyOn()) 
            ItemListParent.gameObject.transform.Translate(0, +ScrollSpeed, 0);
        //可動範囲を超過したら戻す（保持したポジションを代入）
        //if (ItemListParent.gameObject.transform.position.y < 0 ||
        //    ItemListParent.gameObject.transform.position.y > 6000)
        //    ItemListParent.gameObject.transform.position = prePos;
    }
    public void CatalogUpdate()
    {
        for (int i = 0; i < 50; i++)
        {
            //データ割り振り
            if (PlayData.Instance.isGotItems[i])
            {
                CatalogItemInfoController item = Datas[i].GetComponent<CatalogItemInfoController>();
                item.itemNum = i + 1;
                item.UIUpdate();
            }
        }
        ItemListParent.gameObject.transform.localPosition=new Vector2(0,0);
    }
}
