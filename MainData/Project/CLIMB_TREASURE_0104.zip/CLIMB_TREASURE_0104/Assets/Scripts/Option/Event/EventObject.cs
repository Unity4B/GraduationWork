﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// イベントでのオブジェクト操作
/// </summary>
public class EventObject : SingletonClass<EventObject>
{
	/// <summary>
	/// プレイヤークラス
	/// </summary>
	[SerializeField] PlayerMove playerClass = null;
	/// <summary>
	/// タイマークラス
	/// </summary>
	[SerializeField] Timer timeClass = null;
	//-------------------------------------------------------------------------------
	/// <summary>
	/// オブジェクト操作を有効・無効化
	/// </summary>
	/// <param name="objName">対象のオブジェクト名</param>
	/// <param name="isActive">有効か</param>
	public void ObjectActive(string objName,bool isActive)
	{
		switch(objName)
		{
			//プレイヤー
			case "player":
				{
					//nullチェック
					if (this.playerClass == null) { Debug.LogWarning("Playerが指定されていません。"); return; }
					this.playerClass.PlayerActive(isActive);
					break;
				}
			//タイマー
			case "timer":
				{
					//nullチェック
					if (this.playerClass == null) { Debug.LogWarning("Timerが指定されていません。"); return; }
					this.timeClass.isCount = isActive; 
					break;
				}
		}
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 壁キックしたか判定
	/// </summary>
	/// <returns></returns>
	public bool CheckWallJump()
	{
		//nullの場合、処理終了
		if(this.playerClass == null) { return true; }

		return this.playerClass.CheckWallJump();
	}
	//-------------------------------------------------------------------------------

}
