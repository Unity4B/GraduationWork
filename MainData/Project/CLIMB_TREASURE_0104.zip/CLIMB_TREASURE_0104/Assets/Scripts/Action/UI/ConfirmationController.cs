﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

//-------------------------------------------------------------------------------
/// <summary>
/// 確認コマンド
/// </summary>
public class ConfirmationController : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	//確認後、実行するイベント
	UnityEvent action = new UnityEvent();
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 実行
	/// </summary>
	public void Action()
	{
		this.action.Invoke();
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 実行するイベントの追加
	/// </summary>
	/// <param name="action_"></param>
	public void SetAction(UnityAction action_)
	{
		this.action.AddListener(action_);
	}
	//-------------------------------------------------------------------------------
}
