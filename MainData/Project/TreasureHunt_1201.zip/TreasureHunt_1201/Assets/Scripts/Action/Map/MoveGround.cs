﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 動く足場
/// </summary>
public class MoveGround : MonoBehaviour
{
    /// <summary>
    /// フィールド
    /// </summary>

    //-----------------------------------------------
    [SerializeField] Transform startPos = default;        //出発地座標
    [SerializeField] Transform destinationPos = default;  //目的地座標
    [SerializeField] Vector2 nextPos = default;           //次の移動先
    [SerializeField] float speed = 3f;                    //移動速度
    [SerializeField] float waitingTime = 2f;              //次の移動までの待ち時間

    Rigidbody2D rb;
    //-----------------------------------------------

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        nextPos = startPos.position;
        StartCoroutine(Posdesignate());
    }
    private void FixedUpdate()
    {
        Movement();
    }

    /// <summary>
    /// 移動
    /// </summary>
    void Movement()
    {
        transform.position = Vector2.MoveTowards(transform.position, nextPos, speed * Time.deltaTime);
        
    }

    /// <summary>
    /// 移動先指定
    /// </summary>
    IEnumerator Posdesignate()
    {
        while (true)
        {
            if (transform.position == startPos.position)
            {
                yield return new WaitForSeconds(waitingTime);
                nextPos = destinationPos.position;
            }
            if (transform.position == destinationPos.position)
            {
                yield return new WaitForSeconds(waitingTime);
                nextPos = startPos.position;
            }
            yield return null;
        }
        
    }


    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.transform.CompareTag("Player"))
        {
            collision.collider.transform.SetParent(transform);
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.transform.CompareTag("Player"))
        {
            collision.collider.transform.SetParent(null);
        }

    }
    /// <summary>
    /// 移動ラインを表すギズモ
    /// </summary>
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawLine(startPos.position, destinationPos.position);
    }
}
