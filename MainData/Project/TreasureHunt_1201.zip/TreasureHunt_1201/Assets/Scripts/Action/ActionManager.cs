﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//---------------------------------------------
/// <summary>
/// アクションパートの統括管理
/// </summary>
public class ActionManager : SingletonClass<ActionManager>
{
    //---------------------------------------------
    /// <summary>
    /// アクションパートの制限時間
    /// </summary>
    [SerializeField] int timeLimit = 60;
    /// <summary>
    /// 時間カウント
    /// </summary>
    float deltaTime;
    /// <summary>
    /// プレイヤークラス
    /// </summary>
    [SerializeField] PlayerMove playerClass = null;
    /// <summary>
    /// タイマークラス
    /// </summary>
    [SerializeField] Timer timerClass = null;
    //---------------------------------------------
    //プロパティ
    /// <summary>
    /// アクションパートの制限時間
    /// </summary>
    public int TimeLimit
	{
        private set { this.timeLimit = value; }
        get { return this.timeLimit; }
	}
    /// <summary>
    /// 時間カウント
    /// </summary>
    public float DeltaTime
	{
        private set { this.deltaTime = value; }
        get { return this.timeLimit; }
	}

    //---------------------------------------------
    /// <summary>
    /// アクションパートの挙動終了
    /// </summary>
    public void ActionGameEnd()
	{
        //プレイヤー操作ストップ
        this.playerClass.isMove = false;
        //時間カウントストップ
        this.timerClass.isCount = false;
        //シーン切り替え
        SceneChangeManager.Instance.SceneChange("SaleScene");
    }

}
