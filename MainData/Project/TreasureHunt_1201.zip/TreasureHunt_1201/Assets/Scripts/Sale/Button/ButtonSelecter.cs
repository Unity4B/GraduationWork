﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

//---------------------------------------------
/// <summary>
/// ボタン選択
/// </summary>
public class ButtonSelecter : MonoBehaviour
{
    //---------------------------------------------
    /// <summary>
    /// ボタン機能データ
    /// </summary>
    [System.Serializable]
    public struct ButtonData
	{
        /// <summary>
        /// 表示画像イメージ
        /// </summary>
        public Image image;
        /// <summary>
        /// 実行するイベント
        /// </summary>
        [Header("実行するイベント")]
        public UnityEvent action;

	}
    //---------------------------------------------
    /// <summary>
    /// ボタン配列
    /// </summary>
    [SerializeField] ButtonData[] buttons = null;
    /// <summary>
    /// ボタン個数
    /// </summary>
    int buttonCount;
    /// <summary>
    /// 選択中のボタン番号
    /// </summary>
    [SerializeField] int nowButton = 0;
    //---------------------------------------------
    // Start is called before the first frame update
    void Start()
    {
        this.buttonCount = this.buttons.Length;
    }

    // Update is called once per frame
    void Update()
    {
        //前フレームに選択中のボタンを灰色に戻す
        int preButton = this.nowButton;
        this.buttons[preButton].image.color = new Color32(128, 128, 128, 255);
        //選択
        if (InputManager.Instance.input.LeftKeyDown()) this.nowButton--;   //←
        if (InputManager.Instance.input.RightKeyDown()) this.nowButton++;  //→
        //マイナスか最大数超過の時、反対側へ戻す
        if (this.nowButton < 0) this.nowButton += this.buttonCount;
        if (this.nowButton >= this.buttonCount) this.nowButton -= this.buttonCount;
        //選択中のボタンを強調させる
        this.buttons[this.nowButton].image.color = new Color32(255, 255, 255, 255);

        //決定
        if (InputManager.Instance.input.ActionKeyDown())
        {
            //ボタンのアクション実行
            this.buttons[this.nowButton].action.Invoke();
        }
    }
    //---------------------------------------------
}
