﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//---------------------------------------------
/// <summary>
/// 店情報の表記
/// </summary>
public class StoreInfoController : MonoBehaviour
{
    //---------------------------------------------
    /// <summary>
    /// 店関連の管理クラス
    /// </summary>
    [SerializeField] StoreManager sManager = null;
    /// <summary>
    /// 店主の画像イメージ
    /// </summary>
    [SerializeField] Image ownerImage = null;
    /// <summary>
    /// 店の背景
    /// </summary>
    [SerializeField] Image backImage = null;
    /// <summary>
    /// メッセージテキスト
    /// </summary>
    [SerializeField] Text messageText = null;
    /// <summary>
    /// 所持金表示テキスト
    /// </summary>
    [SerializeField] Text moneyText = null;
    /// <summary>
    /// 店のカテゴリ表記テキスト
    /// </summary>
    [SerializeField] Text storeText = null;
    /// <summary>
    /// アイテム情報表示クラス
    /// </summary>
    [SerializeField] ItemInfoController[] itemInfoClass = null;
    //---------------------------------------------
    /// <summary>
    /// UIの更新
    /// </summary>
    public void UIUpdate()
    {
        //店主画像セット
        this.ownerImage.sprite = this.sManager.StoreSelect.OwnerSprite;
        //店背景セット
        this.backImage.sprite = this.sManager.StoreSelect.BackSprite;
        //メッセージセット
        this.messageText.text = this.sManager.StoreSelect.Message[0];
        //所持金セット
        this.moneyText.text = PlayData.Instance.money.ToString() + "G";
        //店のカテゴリセット
        this.storeText.text = this.sManager.GetStoreName(this.sManager.StoreSelect.SCategory);

        //アイテムの更新
        for(int i = 0; i < this.itemInfoClass.Length;i++)
		{
            this.itemInfoClass[i].itemNum = PlayData.Instance.itemNums[i];
            this.itemInfoClass[i].UIUpdate();
		}
    }
    //---------------------------------------------
    /// <summary>
    /// 売却後のUIの更新
    /// </summary>
    public void SaledUIUpdate()
	{
        //メッセージセット
        this.messageText.text = this.sManager.StoreSelect.Message[1];

    }
    //---------------------------------------------
}
