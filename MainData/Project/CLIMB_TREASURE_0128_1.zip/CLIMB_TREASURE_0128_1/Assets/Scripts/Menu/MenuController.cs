﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// メニュー関連操作
/// </summary>
public class MenuController : SingletonClass<MenuController>
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// ボタンスクリプト（現在選択中のオブジェクト設定）
	/// </summary>
	[SerializeField] ButtonSelecter buttonClass = null;
	/// <summary>
	/// メニュー項目ごとのオブジェクト
	/// </summary>
	[Header("メニュー項目ごとのオブジェクト")]
	[SerializeField] GameObject[] menuObj = null;
	/// <summary>
	/// 現在選択中のメニューオブジェクト番号
	/// </summary>
	int nowButtonNum;
	/// <summary>
	/// 選択機能が有効か
	/// </summary>
	bool isSelectActive;
	//-------------------------------------------------------------------------------
	protected override void AwakeInitialize()
	{
		this.isSelectActive = true;

		this.nowButtonNum = 0;

		this.buttonClass.enabled = false;

		//オブジェクト非アクティブ化
		//foreach(GameObject obj in this.menuObj)
		//{
		//	obj.SetActive(false);
		//}
	}
	//-------------------------------------------------------------------------------
	private void Update()
	{
		if(InputManager.Instance.input.CanselKeyDown())
		{
			MenuObjInActiveAction();
		}
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メニュー選択、決定時の処理
	/// </summary>
	public void MenuObjActiveAction()
	{
		//選択機能有効の場合のみ処理
		if (!this.isSelectActive) { return; }

		//現在選択中のボタンを受け取る
		this.nowButtonNum = this.buttonClass.GetNowButton();

		//SE
		SEController.Instance.Play("system_action", 1.0f);

		SelectChange(false);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メニューオブジェクト選択後、キャンセル時の処理
	/// </summary>
	public void MenuObjInActiveAction()
	{
		//選択機能無効の場合のみ処理
		if (this.isSelectActive) { return; }

		//SE
		SEController.Instance.Play("system_cansel", 1.0f);

		SelectChange(true);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メニューでの操作オブジェクト切り替え
	/// </summary>
	/// <param name="isActive">メニュー選択を有効にするか</param>
	public void SelectChange(bool isActive)
	{

		//ボタン選択機能有効・無効化
		this.buttonClass.enabled = isActive;

		//メニューオブジェクトをアクティブ・非アクティブ化
		MenuObjActive(this.nowButtonNum, !isActive);

		//選択機能アクティブ・非アクティブ化
		this.isSelectActive = isActive;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メニューオブジェクトの有効・無効化
	/// </summary>
	/// <param name="num">対象の配列番号</param>
	/// <param name="isActive">有効にするか</param>
	void MenuObjActive(int num,bool isActive)
	{
		//番号が配列範囲外なら処理中断
		if(num < 0  || this.menuObj.Length <= num) { AttentionController.Instance.ActiveAttention("MenuObjの配列外を指定しています。：" + num); return; }

		this.menuObj[num].SetActive(isActive);
	}
	//-------------------------------------------------------------------------------
	//使用したい処理（ボタンにて）
	/// <summary>
	/// ゲーム終了
	/// </summary>
	public void GameEnd()
	{
#if UNITY_EDITOR
		UnityEditor.EditorApplication.isPlaying = false;
#elif UNITY_STANDALONE
			UnityEngine.Application.Quit();
#endif

	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メニューアクティブ・非アクティブ処理を間接的に呼ぶ
	/// </summary>
	public void MenuActive()
	{
		MenuManager.Instance.MenuActive(!MenuManager.Instance.isMenuActive);

		//非アクティブにする場合、ここでアニメーション終了する
		if (MenuManager.Instance.isMenuActive == false) { MenuManager.Instance.AnimationEnd(); }
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// メニューを操作可能・不可能状態にする処理
	/// </summary>
	public void MenuOperationActive()
	{
		//アクティブにしている場合、ここでアニメーション終了
		if(MenuManager.Instance.isMenuActive) { MenuManager.Instance.AnimationEnd(); }

		//メニュー選択機能が向こうの場合は処理しない
		if (!this.isSelectActive) { return; }
		//メニュー選択機能操作
		this.buttonClass.enabled = !this.buttonClass.enabled;

	}
	//-------------------------------------------------------------------------------
}
