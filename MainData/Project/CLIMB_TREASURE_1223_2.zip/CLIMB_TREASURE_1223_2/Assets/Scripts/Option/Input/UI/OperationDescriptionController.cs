﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 操作説明　画像反映
/// </summary>
public class OperationDescriptionController : MonoBehaviour
{
	/// <summary>
	/// 反映するイメージ
	/// </summary>
	[SerializeField] Image image = null;

	[SerializeField] KEYTYPE keyType = KEYTYPE.NONE;

	void Start()
	{
		//タイプごとに表示画像変更
		this.image.sprite = KeyTypeManager.Instance.GetKeySprite(this.keyType);
	}
}
