﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// キータイプ
/// </summary>
public enum KEYTYPE
{
	NONE	= 0,
	ACTION	= 1,
	CANSEL	= 2,
	UP		= 3,
	DOWN	= 4,
	LEFT	= 5,
	RIGHT	= 6,
	EXIT	= 7,
}
//-------------------------------------------------------------------------------
/// <summary>
/// 入力キーの種類管理
/// </summary>
public class KeyTypeManager : SingletonClass<KeyTypeManager>
{
	//-------------------------------------------------------------------------------
    //入力キーの画像リスト
    // 0 : コントローラー 
    // 1 : キーボード
	//		0 : 無
	//		1 : アクション
	//		2 : キャンセル
	//		3 : 上入力
	//		4 : 下入力
	//		5 : 左入力
	//		6 : 右入力
	//		7 : ゲーム終了
    [SerializeField] Sprite[] controllerKeySprites = new Sprite[] { };
    [SerializeField] Sprite[] keyboardKeySprites = new Sprite[] { };
	//-------------------------------------------------------------------------------
	protected override void AwakeInitialize()
	{
		DontDestroyOnLoad(gameObject);
	}
	//-------------------------------------------------------------------------------
	public Sprite GetKeySprite(KEYTYPE keyType)
	{
		switch (InputManager.Instance.input.type)
		{
			case INPUTTYPE.CONROLLER:	return this.controllerKeySprites[(int)keyType];
			case INPUTTYPE.KEYBOARD:	return this.keyboardKeySprites[(int)keyType];
		}
		return null;
	}
	//-------------------------------------------------------------------------------
}
