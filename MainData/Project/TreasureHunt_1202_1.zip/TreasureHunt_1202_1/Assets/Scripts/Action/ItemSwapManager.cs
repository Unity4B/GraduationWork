﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// アイテムの入れ替え管理
/// </summary>
public class ItemSwapManager : MonoBehaviour
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// プレイヤークラス
    /// </summary>
    [SerializeField] PlayerMove playerClass = null;
    //-------------------------------------------------------------------------------
    /// <summary>
    /// アイテム入れ替え
    /// </summary>
    public void ItemSwap()
    {
        //入れ替えるか聞く
        {
            //プレイヤー操作ストップ
            this.playerClass.isMove = false;
            //選択肢表示

        }
        //何と入れ替えるのか


        //選択肢表示
        //選択させる


        //選択したアイテムの場所を-1にする


        //アイテムを追加する処理を呼ぶ

    }
    //-------------------------------------------------------------------------------
}
