﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// チュートリアルでのマップゴール処理
/// </summary>
public class TutorialMapGoal : MapGoal
{
	public override void GoalEvent()
	{
		//チュートリアルでのマップゴール
		EventManager.Instance.EventStart("TUTORIAL_GOAL");
	}
}
