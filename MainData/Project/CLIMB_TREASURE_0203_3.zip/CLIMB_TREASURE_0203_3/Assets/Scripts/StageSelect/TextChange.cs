﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------------------------------------
/// <summary>
/// テキスト変更
/// </summary>
public class TextChange : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 有効か無効か
	/// </summary>
	bool isActive;
	/// <summary>
	/// 有効時のテキスト
	/// </summary>
	[SerializeField] string activeMessage = null;
	/// <summary>
	/// 無効時のテキスト
	/// </summary>
	[SerializeField] string notActiveMessage = null;
	/// <summary>
	/// 反映するテキスト
	/// </summary>
	[SerializeField] Text text = null;
	//-------------------------------------------------------------------------------
	void Start()
	{
		this.isActive = true;
		Active();
	}
	//-------------------------------------------------------------------------------
	public void Active()
	{
		//反転
		this.isActive = !this.isActive;

		//表示切替
		if (isActive) { this.text.text = this.activeMessage; }
		else { this.text.text = this.notActiveMessage; }
	}
	//-------------------------------------------------------------------------------
}
