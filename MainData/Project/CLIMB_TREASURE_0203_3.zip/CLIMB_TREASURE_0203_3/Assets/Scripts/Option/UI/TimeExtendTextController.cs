﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------------------------------------
/// <summary>
/// 時間繰り越しアイテム価格をテキストに反映
/// </summary>
public class TimeExtendTextController : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 使用するテキスト
	/// </summary>
	[SerializeField] Text text = null;
	//-------------------------------------------------------------------------------
	private void Start()
	{
		this.text.text = "時間繰り越し\n" + TimeExtend.Instance.price + "G";
	}
	//-------------------------------------------------------------------------------
}
