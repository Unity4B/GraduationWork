﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------------------------------------
/// <summary>
/// レアリティアイテム価格をテキストに反映
/// </summary>
public class RarityUpTextController : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 使用するテキスト
	/// </summary>
	[SerializeField] Text text = null;
	//-------------------------------------------------------------------------------
	private void Start()
	{
		this.text.text = "レアリティアップ\n" + RarityUp.Instance.price + "G"; 
	}
	//-------------------------------------------------------------------------------
}
