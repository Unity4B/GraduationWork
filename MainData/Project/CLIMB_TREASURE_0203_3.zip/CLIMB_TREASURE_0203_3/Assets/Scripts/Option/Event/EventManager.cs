﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// 実行されたか返す
/// </summary>
/// <returns></returns>
public delegate bool IsAction();
//-------------------------------------------------------------------------------
/// <summary>
/// イベントシステム統括
/// </summary>
public class EventManager : SingletonClass<EventManager>
{
	/// <summary>
	/// イベント状態か
	/// </summary>
	public  bool isEvent;

	/// <summary>
	/// 登録するイベント名
	/// </summary>
	public string[] eventDataNames;

	/// <summary>
	/// イベント開始前にフラグチェックをするイベント名
	/// </summary>
	[SerializeField] string[] eventCheckNames = new string[]{ };

	/// <summary>
	/// イベントフラグ名に名前があるか
	/// </summary>
	bool isEventFlag;

	/// <summary>
	/// 実行中のイベントコルーチン
	/// </summary>
	IEnumerator coroutine;
	//-------------------------------------------------------------------------------
	/// <summary>
	/// イベント処理確認
	/// </summary>
	/// <param name="eventName">イベント名</param>
	public void EventStart(string eventName)
	{
		//イベントリストをチェック
		bool isExist = false;
		foreach (string eName in this.eventDataNames)
		{
			if(eName == eventName) { isExist = true; break; }
		}
		//イベント名がない場合、処理終了
		if (isExist == false) { Debug.LogError("該当するイベント処理がありませんでした：" + eventName); return; }

		//チェックするイベント名かチェック
		bool isEnd = false;
		foreach(string eName in this.eventCheckNames)
		{
			this.isEventFlag = (eName == eventName);
			//存在する場合
			if(this.isEventFlag)
			{
				//イベント終了済みか受け取る
				isEnd = PlayData.Instance.eventData.CheckEventFlag(eName);
				break;
			}
		}
		//イベント終了済みの場合、処理終了
		if (isEnd) { Debug.Log("このイベントは終了しています:" + eventName); return; }

		//すでにイベントが作動中の場合は前のを中断
		if(this.coroutine != null) { StopCoroutine(this.coroutine); }

		//イベントスタート
		this.coroutine = EventEngine(eventName);
		StartCoroutine(this.coroutine);

	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 非同期イベントスタート
	/// </summary>
	/// <param name="data">実行するイベントテキスト</param>
	/// <returns></returns>
	IEnumerator EventEngine(string eventName)
	{
		//イベントファイル読み込み
		List<string> data = FileLoad.DataLoadResource(eventName);

		//イベント状態をONに
		this.isEvent = true;


		//ループ
		for(int n = 0; n < data.Count; n++)
		{
			//終了条件
			IsAction action = (()=>true);
			//イベント終了フラグ
			bool isEnd = false;

			//先頭要素によって処理変更
			switch(data[n].Split(',')[0])
			{
				//オブジェクト有効化
				case "on":	EventObject.Instance.ObjectActive(data[n].Split(',')[1], true); break;
				//オブジェクト無効化
				case "off": EventObject.Instance.ObjectActive(data[n].Split(',')[1], false); break;
				//オブジェクトに行動をさせる
				case "action": EventObject.Instance.ObjectAction(data[n].Split(',')[1]); break;
				//メッセージ表示
				case "msg":
					{
						//オプションがあるか
						if(data[n].Split(',')[3] == "true") { EventMessage.Instance.MessageActive(data[n].Split(',')[1],true);}
						//ない場合
						else { EventMessage.Instance.MessageActive(data[n].Split(',')[1]); }


						//終了条件
						action = EventMessage.Instance.MessageAction(data[n].Split(',')[2]);
						break;
					}
				//シーン切り替え
				case "scene":	SceneChangeManager.Instance.SceneChange(data[n].Split(',')[1]); break;
				//オブジェクトの有効・無効の状態をチェック
				case "check":	action = CheckObject(data[n].Split(',')[1],data[n].Split(',')[2]); break;
				//イベント終了
				case "end":		isEnd = true; break;
			}

			//終了条件が満たされるまで待機 (メニュー中も待機)
			yield return new WaitUntil(() => action() && !MenuManager.Instance.isMenuActive);
			yield return null;

			//フラグがONなら強制終了
			if (isEnd) { break; }
		}


		//イベント終了
		this.isEvent = false;

		//イベントフラグに存在する場合
		if (this.isEventFlag) 
		{
			//イベントフラグを終了済みにする
			PlayData.Instance.eventData.EventEnd(eventName);
		}

		//終了処理
		EventMessage.Instance.MessageEnd(); //メッセージ終了
		this.coroutine = null;				//コルーチンリセット

		yield break;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// オブジェクトの状態を確認するコマンドを返す
	/// </summary>
	/// <param name="objName">確認したい項目名</param>
	/// <param name="activeName">有効・無効のどちらをチェックしたいか</param>
	/// <returns></returns>
	IsAction CheckObject(string objName,string activeName)
	{
		IsAction action = (() => true);

		//有効・無効どっちをチェックするのか
		bool isCheck = true;
		if(activeName == "false") { isCheck = false; }
		//どちらでもない場合、エラー
		else if(activeName != "true") { Debug.LogError("イベント・チェックしたい状態が正しくありません。：" + activeName); }


		//チェックするオブジェクト
		switch(objName)
		{
			//アイテム入れ替え
			case "itemswap": action = (() => ItemSwapManager.Instance.isActive == isCheck); break;
			//エラー処理
			default: Debug.LogError("イベント・チェックするオブジェクトが設定されていませんでした。：" + objName); break;
		}

		return action;
	}
	//-------------------------------------------------------------------------------
}
