﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Catalog : SingletonClass<Catalog>
{
    /// <summary>
    /// アイテムデータを表示するプレファブ
    /// </summary>
    [SerializeField] GameObject itemDataPrefab = null;
    /// <summary>
    /// アイテムリストの親とするオブジェクト
    /// </summary>
    [SerializeField] GameObject ItemListParent = null;
    /// <summary>
    /// スクロール速度（初期設定：10）
    /// </summary>
    public float ScrollSpeed = 10;

	protected override void Awake()
	{
		base.Awake();

        DontDestroyOnLoad(gameObject);

    }

    // Start is called before the first frame update
    void Start()
    {
        //アイテムデータ確保　50個分
        for (int i = 0; i < 50; i++) 
        {
            GameObject Datas = Instantiate(itemDataPrefab);
            //子オブジェクト化
            Datas.transform.SetParent(ItemListParent.transform);
            //位置調整
            Datas.transform.localPosition = new Vector2(-440, 470 - i * 120);
            //名前を番号化
            Datas.name = itemDataPrefab.name + (i + 1);
            //データ割り振り
            if (!PlayData.Instance.isGotItems[i]) continue;
            CatalogItemInfoController item = Datas.GetComponent<CatalogItemInfoController>();
            item.itemNum = i + 1;
            item.UIUpdate();
        }
    }

    // Update is called once per frame
    void Update()
    {
        //前フレームのポジションを保持
        Vector3 prePos = ItemListParent.gameObject.transform.position;
        //上下キーでスクロール
        if (InputManager.Instance.input.UpKeyOn()) 
            ItemListParent.gameObject.transform.Translate(0, -ScrollSpeed, 0);
        if (InputManager.Instance.input.DownKeyOn()) 
            ItemListParent.gameObject.transform.Translate(0, +ScrollSpeed, 0);
        //可動範囲を超過したら戻す（保持したポジションを代入）
        if (ItemListParent.gameObject.transform.position.y < 540 ||
            ItemListParent.gameObject.transform.position.y > 5480)
            ItemListParent.gameObject.transform.position = prePos;
    }
}
