﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// ゲーム全体の統括
/// </summary>
public class GameManager : SingletonClass<GameManager>
{
	//-------------------------------------------------------------------------------
	protected override void Awake()
	{
		base.Awake();
		//破棄処理が呼ばれている場合、処理終了
		if (this.isDestroy) { return; }

		DontDestroyOnLoad(gameObject);
	}
	//-------------------------------------------------------------------------------
	void Update()
	{
		if (InputManager.Instance.input.ExitKeyDown())
		{
#if UNITY_EDITOR
			UnityEditor.EditorApplication.isPlaying = false;
#elif UNITY_STANDALONE
			UnityEngine.Application.Quit();
#endif
		}
		if(InputManager.Instance.input.ActionKeyDown())
		{
			SEController.Instance.Play("test01");
		}
	}
}
