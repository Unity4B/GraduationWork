﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// デバック管理クラス
/// </summary>
public class DebugManager : SingletonClass<DebugManager>
{
    /// <summary>
    /// デバックモードか
    /// </summary>
    public bool isDebug;

    void Start()
    {

        DontDestroyOnLoad(gameObject);
        this.isDebug = false;
    }

    void Update()
    {
        //デバックモード切替
        if(Input.GetKeyDown(KeyCode.F1))
		{
            this.isDebug = !this.isDebug;
		}
        //デバックモードでない場合、処理せず
		if (!this.isDebug) { return; }


		if (Input.GetKeyDown(KeyCode.F2)) { SceneChangeManager.Instance.SceneChange("SaleScene"); }
		if (Input.GetKeyDown(KeyCode.F3)) { SceneChangeManager.Instance.SceneChange("ActionForestMap"); }
		if (Input.GetKeyDown(KeyCode.F4)) { BGMController.Instance.Play("testBGM01"); }

    }
}
