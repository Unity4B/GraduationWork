﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//---------------------------------------------
/// <summary>
/// カタログでのアイテム情報表示
/// </summary>
public class CatalogItemInfoController : ItemInfoController
{
    //---------------------------------------------
    /// <summary>
    /// アイテムカテゴリ名表示テキスト
    /// </summary>
    [SerializeField] Text icText = default;
    //---------------------------------------------
    protected override void SetItemUI()
    {
        base.SetItemUI();
        //金額設定
        this.itemPrice = this.item.Price;
        //カテゴリ名表示
        this.icText.text = ItemManager.Instance.GetItemName(this.item.ICategory);
        //金額表示
        this.priceText.text = this.itemPrice.ToString() + "G";
    }
    //---------------------------------------------
    protected override void SetDefaultUI()
	{
		base.SetDefaultUI();

        //カテゴリ名表示
        this.icText.text = "不明";
        //金額表示
        this.priceText.text = "???G";
    }

}
