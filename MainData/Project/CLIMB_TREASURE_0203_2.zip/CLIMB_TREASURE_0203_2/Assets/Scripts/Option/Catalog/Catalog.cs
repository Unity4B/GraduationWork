﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;

public class Catalog : SingletonClass<Catalog>
{
    /// <summary>
    /// アイテムデータを表示するプレファブ
    /// </summary>
    [SerializeField] GameObject itemDataPrefab = null;
    /// <summary>
    /// アイテムリストの親とするオブジェクト
    /// </summary>
    [SerializeField] GameObject ItemListParent = null;
    /// <summary>
    /// スクロール速度（初期設定：10）
    /// </summary>
    public float ScrollSpeed = 10;
    /// <summary>
    /// アイテムデータ配列
    /// </summary>
    List<CatalogItemInfoController> Datas = new List<CatalogItemInfoController>();
    /// <summary>
    /// 前回更新時のデータ
    /// </summary>
    bool[] preIsGotItems;

	protected override void AwakeInitialize()
	{
        DontDestroyOnLoad(gameObject.transform.root);

        //初期化
        //アイテムデータ確保　50個分
        for (int i = 0; i < 50; i++)
        {
            GameObject data = Instantiate(itemDataPrefab);
            //子オブジェクト化
            data.transform.SetParent(ItemListParent.transform);
            //位置調整
            data.transform.localPosition = new Vector2(-440, -i * 120 - 50);
            //名前を番号化
            data.name = itemDataPrefab.name + (i + 1);
            //データ割り振り
            CatalogItemInfoController item = data.GetComponent<CatalogItemInfoController>();
            if (PlayData.Instance.isGotItems[i])
            {
                item.itemNum = i + 1;
            }
            else
			{
                item.itemNum = -1;
			}
            item.UIUpdate();
            //データ配列に追加
            this.Datas.Add(item);
        }

        //アイテム取得情報
        //配列の長さ
        int length = PlayData.Instance.isGotItems.Length;
        this.preIsGotItems = new bool[length];
        //値のコピー
        Array.Copy(PlayData.Instance.isGotItems, this.preIsGotItems, length);

    }

    // Update is called once per frame
    void Update()
    {
		//アップデート命令が有効な場合、アップデート
		if (CheckItemGotData()) { CatalogUpdate(); }

        //前フレームのポジションを保持
        //Vector3 prePos = ItemListParent.gameObject.transform.position;
        //上下キーでスクロール
        if (InputManager.Instance.input.UpKeyOn()) 
            ItemListParent.gameObject.transform.Translate(0, -ScrollSpeed, 0);
        if (InputManager.Instance.input.DownKeyOn()) 
            ItemListParent.gameObject.transform.Translate(0, +ScrollSpeed, 0);
        //可動範囲を超過したら戻す（保持したポジションを代入）
        //if (ItemListParent.gameObject.transform.position.y < 0 ||
        //    ItemListParent.gameObject.transform.position.y > 6000)
        //    ItemListParent.gameObject.transform.position = prePos;
    }
    //-------------------------------------------------------------------------------//柄子
    /// <summary>
    /// アイテムの取得情報が変わっているか
    /// </summary>
    bool CheckItemGotData()
	{
        //データチェック
        for (int i = 0; i < PlayData.Instance.isGotItems.Length; i++)
        {
            //情報が違う場合か
            if (PlayData.Instance.isGotItems[i] != this.preIsGotItems[i]) { return true; }
        }

        return false;
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// カタログの情報更新
    /// </summary>
    void CatalogUpdate()
    {
        //配列の長さ
        int length = PlayData.Instance.isGotItems.Length;


        for (int i = 0; i < length; i++)
        {
            bool isGotItem = PlayData.Instance.isGotItems[i];
            //情報が違った場合、更新
            if (isGotItem != this.preIsGotItems[i])
            {
                //取得済みの場合
				if (isGotItem) { this.Datas[i].itemNum = i + 1;}
				//未取得の場合
				else { this.Datas[i].itemNum = -1; }
                //UI更新
                this.Datas[i].UIUpdate();
            }
        }
        //アイテム取得情報更新
        Array.Copy(PlayData.Instance.isGotItems, this.preIsGotItems, length);

        ItemListParent.gameObject.transform.localPosition=new Vector2(0,0);
    }
    //-------------------------------------------------------------------------------
}
