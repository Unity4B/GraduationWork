﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// ジャンプ力が下がる床
/// </summary>
public class LowJumpGround : GroundBase
{
    [SerializeField] float lowJumpForce = 10f;  //下がったジャンプ力
    [SerializeField] float preJumpForce = 15f;  //戻ったジャンプ力

    protected override void PlayerStayCollision(Collision2D collision)
    {
        base.PlayerStayCollision(collision);
        collision.transform.GetComponent<PlayerMove>().jumpForce = lowJumpForce;
    }

    protected override void PlayerExitCollision(Collision2D collision)
    {
        collision.transform.GetComponent<PlayerMove>().jumpForce = preJumpForce;
        base.PlayerExitCollision(collision);
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.transform.CompareTag("Player"))
        {
            collision.transform.GetComponent<PlayerMove>().jumpForce = preJumpForce;
        }
    }
}
