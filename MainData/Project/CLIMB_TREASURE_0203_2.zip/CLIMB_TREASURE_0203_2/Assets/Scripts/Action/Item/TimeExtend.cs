﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//-------------------------------------------------------------------------------
/// <summary>
/// 時間延長効果
/// </summary>
public class TimeExtend : SingletonClass<TimeExtend>
{
	//-------------------------------------------------------------------------------
	//終了地点からもう一度スタートする

	/// <summary>
	/// 有効か無効か
	/// </summary>
	public bool isActive;
	/// <summary>
	/// リスタート地点(終了地点)
	/// </summary>
	Vector2 reStartPos;
	/// <summary>
	/// 処理中か
	/// </summary>
	public bool isStart;
	/// <summary>
	/// 必要金額
	/// </summary>
	[Header("必要金額")]
	public int price = 1000;
	//-------------------------------------------------------------------------------
	protected override void AwakeInitialize()
	{
		DontDestroyOnLoad(gameObject);
		this.isActive = false;
		this.isStart = false;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// リスタート処理スタート
	/// </summary>
	public void ProcessStart()
	{
		//処理開始
		this.isStart = true;

		//終了地点記録
		this.reStartPos = GameObject.FindGameObjectWithTag("Player").transform.position;

		//現在のシーンに切り替え
		SceneChangeManager.Instance.SceneChange(SceneManager.GetActiveScene().name);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// プレイヤー位置調整
	/// </summary>
	public void Restart()
	{
		//プレイヤー取得
		GameObject player = GameObject.FindGameObjectWithTag("Player");
		//移動
		player.transform.position = this.reStartPos;

		//終了
		this.isStart = false;

		//無効化
		this.isActive = false;
	}
	//-------------------------------------------------------------------------------
}
