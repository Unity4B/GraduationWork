﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// イベントフラグデータ
/// </summary>
[System.Serializable]
public class EventData
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// イベントフラグ名
	/// </summary>
	string[] eventFlagNames;
	//イベント番号
	//	0:初めから
	/// <summary>
	/// イベント終了済みフラグ保存
	/// </summary>
	[SerializeField] bool[] isEventFlags = new bool[]{ };
	/// <summary>
	/// イベントフラグ格納
	/// </summary>
	Dictionary<string,int> eventDatas;
	//-------------------------------------------------------------------------------
	public EventData()
	{
		//イベント名設定
		this.eventFlagNames = new string[]
		{
			"NEW_ACTION_IN",	//初めてアクションパートに入った
			"NEW_SALE_IN",		//初めてセールパートに入った
			"NEW_STAGESELECT_IN",	//初めてステージ選択に入った
			"NEW_CLEAR",
		};

		this.isEventFlags = new bool[this.eventFlagNames.Length];
		this.eventDatas = new Dictionary<string, int>();

		//フラグ格納初期化
		for(int i = 0; i < this.eventFlagNames.Length;i++)
		{
			this.isEventFlags[i] = false;
			this.eventDatas.Add(this.eventFlagNames[i],i);
		}

	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// イベントを終了済みにする
	/// </summary>
	/// <param name="eName">イベントフラグ名</param>
	public void EventEnd(string eName)
	{
		//イベントフラグ名が登録されていない場合
		if (!this.eventDatas.ContainsKey(eName))
		{
			//エラー処理＆終了
			Debug.LogWarning("イベントフラグ名が登録されていません：" + eName);

			return;
		}

		//フラグ終了済みにする
		this.isEventFlags[this.eventDatas[eName]] = true;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// イベントフラグが有効かチェック
	/// </summary>
	/// <param name="eName">イベントフラグ名</param>
	/// <returns></returns>
	public bool CheckEventFlag(string eName)
	{
		//イベントフラグ名が登録されていない場合
		if(!this.eventDatas.ContainsKey(eName)) 
		{
			//エラー処理＆終了
			Debug.LogWarning("イベントフラグ名が登録されていません：" + eName);

			return false; 
		}

		//フラグ検索
		bool isFlag = this.isEventFlags[this.eventDatas[eName]];
		return isFlag;
	}
}
