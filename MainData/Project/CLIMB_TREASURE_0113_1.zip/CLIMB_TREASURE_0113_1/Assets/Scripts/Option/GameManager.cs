﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// ゲーム全体の統括
/// </summary>
public class GameManager : SingletonClass<GameManager>
{
	//-------------------------------------------------------------------------------
	protected override void AwakeInitialize()
	{
		DontDestroyOnLoad(gameObject);
	}
	//-------------------------------------------------------------------------------
	void Update()
	{
		if (InputManager.Instance.input.ExitKeyDown())
		{
#if UNITY_EDITOR
			UnityEditor.EditorApplication.isPlaying = false;
#elif UNITY_STANDALONE
			UnityEngine.Application.Quit();
#endif
		}

	}
}
