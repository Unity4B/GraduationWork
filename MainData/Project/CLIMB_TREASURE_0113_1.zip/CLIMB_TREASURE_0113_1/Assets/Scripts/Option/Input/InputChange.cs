﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// 入力切替
/// </summary>
public class InputChange : MonoBehaviour
{
    //-------------------------------------------------------------------------------
    public void InputChangeController()
	{
        InputManager.Instance.input = new InputController();
	}
    //-------------------------------------------------------------------------------
    public void InputChangeKeyboard()
	{
        InputManager.Instance.input = new InputKeyBoard();
	}
    //-------------------------------------------------------------------------------
}
