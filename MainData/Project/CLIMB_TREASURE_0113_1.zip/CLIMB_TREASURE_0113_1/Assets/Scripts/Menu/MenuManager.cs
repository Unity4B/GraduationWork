﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// メニュー管理
/// </summary>
public class MenuManager : SingletonClass<MenuManager>
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// メニューを開いているか
    /// </summary>
    public bool isMenuActive;
	//-------------------------------------------------------------------------------
	void Start()
	{
        MenuActive(false);
	}
	//-------------------------------------------------------------------------------
	void Update()
    {
        //メニューアクティブ・非アクティブ化
        if (InputManager.Instance.input.MenuKeyDown())
        {
            MenuActive(!this.isMenuActive);
        }
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// メニューアクティブ・非アクティブ
    /// </summary>
    /// <param name="isActive">アクティブにするか</param>
    public void MenuActive(bool isActive)
	{
        MenuController.Instance.gameObject.SetActive(isActive);
        //メニュー状態更新
        this.isMenuActive = isActive;
	}
    //-------------------------------------------------------------------------------
}
