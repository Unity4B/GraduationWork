﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// 追跡プログラム
/// </summary>
public class Tracking : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 追跡対象
	/// </summary>
	[Header("追跡対象")]
	[SerializeField] GameObject targetObj = null;
	/// <summary>
	///	ずらす座標値
	/// </summary>
	[Header("ずらす座標値")]
	[SerializeField] Vector2 shiftPos = new Vector2();
	//-------------------------------------------------------------------------------
	void Update()
	{
		transform.position = (Vector2)this.targetObj.transform.position + this.shiftPos;	
	}
}
