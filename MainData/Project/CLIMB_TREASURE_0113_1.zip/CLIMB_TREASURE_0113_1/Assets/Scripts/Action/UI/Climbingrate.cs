﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Climbingrate : MonoBehaviour
{
    [Header("登頂率")]
    [SerializeField] float distance = 0f;     //距離
    [SerializeField] float standert = 0f;     //基準
    [SerializeField] float presentvalue = 0f; //基準
    [SerializeField] GameObject player = null;//プレイヤ
    void Awake()
    {
        standert = player.transform.position.y;
    }

    void Update()
    {
        presentvalue = player.transform.position.y;
        distance = Mathf.Abs(standert - presentvalue);
        //Debug.Log(distance);
    }
}
