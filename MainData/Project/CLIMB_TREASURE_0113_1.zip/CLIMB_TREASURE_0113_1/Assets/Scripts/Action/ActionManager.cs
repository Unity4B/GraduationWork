﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//-------------------------------------------------------------------------------
/// <summary>
/// アクションパートの統括管理
/// </summary>
public class ActionManager : SingletonClass<ActionManager>
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// アクションパートの制限時間
    /// </summary>
    [SerializeField] int timeLimit = 60;
    /// <summary>
    /// 時間カウント
    /// </summary>
    float deltaTime;
    /// <summary>
    /// プレイヤークラス
    /// </summary>
    [SerializeField] PlayerMove playerClass = null;
    /// <summary>
    /// タイマークラス
    /// </summary>
    [SerializeField] Timer timerClass = null;
	//-------------------------------------------------------------------------------
	//プロパティ
	/// <summary>
	/// アクションパートの制限時間
	/// </summary>
	public int TimeLimit
	{
        private set { this.timeLimit = value; }
        get { return this.timeLimit; }
	}
    /// <summary>
    /// 時間カウント
    /// </summary>
    public float DeltaTime
	{
        private set { this.deltaTime = value; }
        get { return this.timeLimit; }
	}
    //-------------------------------------------------------------------------------
    protected override void AwakeInitialize()
	{
        //処理中なら、リスタートを呼び出す
		if (TimeExtend.Instance.isStart) { TimeExtend.Instance.Restart(); }

        //イベント呼び出し（チュートリアル）
        EventManager.Instance.EventStart("NEW_ACTION_IN");
    }
    //-------------------------------------------------------------------------------
    void Start()
    {
        BGMController.Instance.Play(SceneManager.GetActiveScene().name + "BGM", 0.3f);
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// アクションパートの挙動終了
    /// </summary>
    public void ActionGameEnd()
	{
        //プレイヤー操作ストップ
        this.playerClass.PlayerActive(false);
        //時間カウントストップ
        this.timerClass.isCount = false;
        
        //時間延長の場合、リスタート処理
        if (TimeExtend.Instance.isActive) { TimeExtend.Instance.ProcessStart(); return; }

        //アイテムの効果をリセット
        TimeExtend.Instance.isActive = false;   //リスタート効果
        RarityUp.Instance.isActive = false;     //レアアイテム率アップ

        //シーン切り替え
        SceneChangeManager.Instance.SceneChange("SaleScene");
    }
    //-------------------------------------------------------------------------------

}
