﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// セーブ機能
/// </summary>
public class SaveData
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// データをJson形式に変換
	/// </summary>
	/// <typeparam name="T">変換されるクラスの型</typeparam>
	/// <param name="data">変換するクラス</param>
	/// <returns>変換後の文字列</returns>
	string DataToJson<T>(T data)
	{
		return JsonUtility.ToJson(data);
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// セーブ（PlayerPrefに保存）
	/// </summary>
	/// <param name="dataName">保存名</param>
	public void Save(string dataName)
	{
		string json = DataToJson(PlayData.Instance);
		PlayerPrefs.SetString(dataName, json);
		PlayerPrefs.Save();

		Debug.Log("セーブ完了：" + dataName + "\n内容：" + json);
	}
	//-------------------------------------------------------------------------------
}
