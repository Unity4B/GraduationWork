﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// プレイデータ
/// </summary>
[System.Serializable]
public class PlayData : SingletonClass<PlayData>
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// アイテムを持てる量
    /// </summary>
    [Header("持てるアイテムの量")]
    [SerializeField] int hasItemValue = 0;
    /// <summary>
    /// 所持アイテムの番号リスト
    /// </summary>
    public int[] itemNums;
    /// <summary>
    /// 所持金
    /// </summary>
    public int money;
    /// <summary>
    /// 日数カウント
    /// </summary>
    public int dayCnt;
    /// <summary>
    /// アイテムをゲットしたことがあるか
    /// </summary>
    public bool[] isGotItems;
    /// <summary>
    /// イベントフラグデータ
    /// </summary>
    public EventData eventData;
    //-------------------------------------------------------------------------------
    protected override void AwakeInitialize()
	{
        DontDestroyOnLoad(gameObject);

        //ItemManagerのAwake後に呼び出さないとエラー?

        //初期化
        //インベントリ
        this.itemNums = new int[this.hasItemValue];
        InventoryReset();

        //所持金
        this.money = 0;

        //経過日数
        this.dayCnt = 1;

        //アイテムカタログデータ
        //アイテムの数だけ生成
        this.isGotItems = new bool[ItemManager.Instance.itemList.Count];
        for (int i = 0; i < this.isGotItems.Length; i++)
        {
            this.isGotItems[i] = false;
        }

        //イベントフラグデータ
        this.eventData = new EventData();
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// インベントリにアイテムを追加
    /// </summary>
    /// <param name="itemNum">追加するアイテム番号</param>
    public void AddItem(int itemNum)
	{
        //インベントリに空きがあるかチェック
        bool isNull = false;
        int num;
        for(num = 0; num < this.itemNums.Length; num++)
		{
            if(this.itemNums[num] == -1) { isNull = true; break; }
		}

        //もしインベントリが埋まっている場合、ほかのアイテムと入れ替えるか聞く
        if (isNull == false) { ItemSwapManager.Instance.ExistenceItemSwap(itemNum); return; }

        //インベントリに格納
        this.itemNums[num] = itemNum;
	}
    //-------------------------------------------------------------------------------
    /// <summary>
    /// アイテムを登録した状態にする
    /// </summary>
    /// <param name="itemNum">登録するアイテム番号</param>
    public void ItemRegister(int itemNum)
	{
        this.isGotItems[itemNum - 1] = true;

        //Debug
        Debug.Log("アイテムデータを登録状態にしました。：アイテム番号" + itemNum);
	}
    //-------------------------------------------------------------------------------
    //インベントリ(所持アイテムの番号リスト)の内容をリセット
    public void InventoryReset()
	{
        for (int i = 0; i < this.itemNums.Length; i++)
        {
            this.itemNums[i] = -1;
        }
    }
    //-------------------------------------------------------------------------------
}
