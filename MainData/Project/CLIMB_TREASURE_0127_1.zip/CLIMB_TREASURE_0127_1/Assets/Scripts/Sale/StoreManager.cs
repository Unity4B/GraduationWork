﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//---------------------------------------------
//---------------------------------------------
/// <summary>
/// 店管理
/// </summary>
public class StoreManager : SingletonClass<StoreManager>
{
    /// <summary>
    /// 店カテゴリ
    /// </summary>
    public enum Category
    {
        NONE = -1,
        /// <summary>
        /// 薬屋
        /// </summary>
        MEDICIN = 0,
        /// <summary>
        /// 道具屋
        /// </summary>
        TOOL = 1,
        /// <summary>
        /// 武具屋
        /// </summary>
        ARMOR = 2,
        /// <summary>
        /// 宝石店
        /// </summary>
        JEWELRY = 3,
        /// <summary>
        /// 市場
        /// </summary>
        MARKET = 4,
    }
    //---------------------------------------------
    /// <summary>
    /// 店リスト
    /// </summary>
    public Store[] storeList;
    /// <summary>
    /// 選ばれた店
    /// </summary>
    Store storeSelect;
    /// <summary>
    /// 店選択画面
    /// </summary>
    [SerializeField] GameObject storeOut = null;
    /// <summary>
    /// 店内画面
    /// </summary>
    [SerializeField] GameObject storeIn = null;
    /// <summary>
    /// 店情報表示クラス
    /// </summary>
    [SerializeField] StoreInfoController storeInfoClass = null;
    //---------------------------------------------
    //プロパティ
    /// <summary>
    /// 選ばれた店
    /// </summary>
    public Store StoreSelect
    {
        private set { this.storeSelect = value; }
        get { return this.storeSelect; }
    }
    //---------------------------------------------
    protected override void AwakeInitialize()
    {
        //店設定
        this.storeList = new Store[]
        {
            new Store(Category.MEDICIN, new ItemManager.Category[] { ItemManager.Category.PLANT,    ItemManager.Category.DLUG}),    //薬屋
            new Store(Category.TOOL,    new ItemManager.Category[] { ItemManager.Category.TOOL,     ItemManager.Category.BOOK}),    //道具屋
            new Store(Category.ARMOR,   new ItemManager.Category[] { ItemManager.Category.ARMOR,    ItemManager.Category.WEAPON}),  //武具屋
            new Store(Category.JEWELRY, new ItemManager.Category[] { ItemManager.Category.JEWEL,    ItemManager.Category.RING}),    //宝石店
            new Store(Category.MARKET,  new ItemManager.Category[] { ItemManager.Category.FOOD}), //市場
        };

        //チュートリアルイベント
        EventManager.Instance.EventStart("NEW_SALE_IN");

    }
	//---------------------------------------------
	void Start()
	{
        //BGM再生
        BGMController.Instance.Play("StoreBGM");		
	}
	//---------------------------------------------
	/// <summary>
	/// 店カテゴリを文字列に変換
	/// </summary>
	/// <param name="category">変換したい店カテゴリ</param>
	/// <returns></returns>
	public string GetStoreName(Category category)
    {
        string sName = "";
        switch (category)
        {
            case Category.MEDICIN:  sName = "薬屋"; break;
            case Category.TOOL:     sName = "道具屋"; break;
            case Category.ARMOR:    sName = "武具屋"; break;
            case Category.JEWELRY:  sName = "宝石店"; break;
            case Category.MARKET:   sName = "市場"; break;
        }
        return sName;
    }
    //---------------------------------------------
    /// <summary>
    /// 店をセット
    /// </summary>
    /// <param name="num">選ばれた店番号</param>
    public void SetStoreSelect(int num)
    {
        //エラーチェック
        if (num < 0 || storeList.Length <= num) 
        {
            //エラーの場合
            Debug.LogError("範囲外の店番号です。入力値：" + num);
            return;
        }

        StoreSelect = this.storeList[num];

        //UI更新
        this.storeInfoClass.UIUpdate();
    }
    //---------------------------------------------
    /// <summary>
    /// 店画面切り替え
    /// </summary>
    public void StoreScreenChange()
	{
        bool isActive = this.storeOut.activeSelf;

        this.storeIn.SetActive(isActive);
        this.storeOut.SetActive(!isActive);
	}
    //---------------------------------------------
    /// <summary>
    /// セーブする
    /// </summary>
    public void Save()
	{
        //セーブ表示
        AttentionController.Instance.ActiveAttention("セーブをしました。");

        //セーブ
        DataManager.Instance.Save();
	}
    //---------------------------------------------
}
