﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// ロード機能
/// </summary>
public class LoadData
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// ロード（PlayerPrefから読み込み）
	/// </summary>
	/// <typeparam name="T">受け取りたいクラスの型</typeparam>
	/// <param name="dataName">保存名</param>
	/// <returns>読み込んだデータ</returns>
	public void Load(string dataName)
	{
		string json = PlayerPrefs.GetString(dataName);
		JsonUtility.FromJsonOverwrite(json, PlayData.Instance);
	}
	//-------------------------------------------------------------------------------
}
