﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------------------------------------
/// <summary>
/// キー画像表示
/// </summary>
public class KeyTypeController : MonoBehaviour
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 初期表示するキー
    /// </summary>
    [SerializeField] KEYTYPE kType = KEYTYPE.NONE;
    /// <summary>
    /// 使用するImage
    /// </summary>
    [SerializeField] Image kImage = null;
	/// <summary>
	/// 表示している操作媒体
	/// </summary>
	INPUTTYPE iType;
	//-------------------------------------------------------------------------------
	void Awake()
	{
		this.iType = InputManager.Instance.input.type;

		SetKeySprite(this.kType);	
	}
	//-------------------------------------------------------------------------------
	void Update()
	{
		//操作媒体が変わっていたら更新
		if(InputManager.Instance.input.type != this.iType)
		{
			SetKeySprite(this.kType);

			//更新
			this.iType = InputManager.Instance.input.type;
		}
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// キー画像を表示
	/// </summary>
	/// <param name="kType">表示するキー</param>
	public void SetKeySprite(KEYTYPE kType_)
	{
        this.kImage.sprite = KeyTypeManager.Instance.GetKeySprite(kType_);
	}
    //-------------------------------------------------------------------------------
}
