﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//---------------------------------------------
/// <summary>
/// 店でのアイテム情報表示
/// </summary>
public class StoreItemInfoController : ItemInfoController
{
    //---------------------------------------------
    /// <summary>
    /// ボーナス画像表記イメージ
    /// </summary>
    [SerializeField] Image bonusImage = default;
    //---------------------------------------------
    public override void UIUpdate()
    {
        //アイテム無しなら処理せず
        if (this.itemNum <= 0) { return; }


        base.UIUpdate();

        //金額設定
        //ボーナス加算かチェック
        bool isBonus =StoreManager.Instance.StoreSelect.CheckBonusItem(this.item.ICategory);
        if (isBonus) { this.itemPrice = (int)((float)item.Price * 1.1f); }
        else        { this.itemPrice = item.Price; }

        this.bonusImage.enabled = isBonus;
        //金額表示
        this.priceText.text = this.itemPrice.ToString() + "G";

    }
    //---------------------------------------------
}
