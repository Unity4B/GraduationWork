﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------------------------------------
/// <summary>
/// アイテムの入れ替え管理
/// </summary>
public class ItemSwapManager : SingletonClass<ItemSwapManager>
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 動作中か
    /// </summary>
    public bool isActive;
    /// <summary>
    /// あふれたアイテムの番号
    /// </summary>
    int itemNum;
    /// <summary>
    /// プレイヤークラス
    /// </summary>
    [SerializeField] PlayerMove playerClass = null;
    /// <summary>
    /// アイテムを入れ替えるかの選択肢
    /// </summary>
    [SerializeField] GameObject existenceObj = null;
    /// <summary>
    /// 捨てるアイテムの選択肢
    /// </summary>
    [SerializeField] GameObject selectObj = null;
    /// <summary>
    /// アイテム表示画像Image
    /// </summary>
    [SerializeField] Image itemImage = null;
	//-------------------------------------------------------------------------------
	void Start()
	{
        //UI非表示
        this.existenceObj.SetActive(false);
        this.selectObj.SetActive(false);
        this.isActive = false;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// アイテム入れ替えを聞く表示
	/// </summary>
	/// <param name="num">あふれたアイテムの番号</param>
	public void ExistenceItemSwap(int num)
    {
        this.itemNum = num;

        //アイテム表示
        this.itemImage.sprite = ItemManager.Instance.itemSprites[num - 1];
        //プレイヤー操作ストップ
        this.playerClass.PlayerActive(false);
        //選択肢表示
        this.existenceObj.SetActive(true);

        this.isActive = true;
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 捨てるアイテムの選択肢表示
    /// </summary>
    public void SelectItemSwap()
	{
        //入れ替え選択肢非表示
        this.existenceObj.SetActive(false);
        //アイテム選択肢表示
        this.selectObj.SetActive(true);
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// アイテムを入れ替える
    /// </summary>
    /// <param name="num">アイテムの配列番号</param>
    public void ItemChange(int num)
	{
        //選択したアイテムの場所を空にする
        PlayData.Instance.itemNums[num] = -1;

        //アイテムを追加する処理を呼ぶ
        PlayData.Instance.AddItem(this.itemNum);
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 入れ替え終了
    /// </summary>
    public void ItemSwapEnd()
	{
        //アイテム番号リセット
        this.itemNum = -1;

        //UI非表示
        this.existenceObj.SetActive(false);
        this.selectObj.SetActive(false);

        //プレイヤー操作再開
        this.playerClass.PlayerActive(true);

        this.isActive = false;
    }
}
