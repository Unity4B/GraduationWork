﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//---------------------------------------------
/// <summary>
/// 店でのアイテム情報表示
/// </summary>
public class StoreItemInfoController : ItemInfoController
{
    //---------------------------------------------
    /// <summary>
    /// ボーナス画像表記イメージ
    /// </summary>
    [SerializeField] Image bonusImage = default;
    //---------------------------------------------
    protected override void SetItemUI()
    {
        base.SetItemUI();

        //金額設定
        //ボーナス加算かチェック
        bool isBonus =StoreManager.Instance.StoreSelect.CheckBonusItem(this.item.ICategory);
        if (isBonus) { this.itemPrice = (int)((float)item.Price * 1.1f); }
        else        { this.itemPrice = item.Price; }
        //ボーナス有無表示
        this.bonusImage.enabled = isBonus;
        //金額表示
        this.priceText.text = this.itemPrice.ToString() + "G";
    }
	//---------------------------------------------
	protected override void SetDefaultUI()
	{
		base.SetDefaultUI();

        //ボーナス有無表示
        this.bonusImage.enabled = false;
        //金額表示
        this.priceText.text = "";
    }
}
