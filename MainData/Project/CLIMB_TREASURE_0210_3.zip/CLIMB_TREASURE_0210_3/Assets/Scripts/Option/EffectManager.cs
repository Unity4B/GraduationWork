﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// エフェクト生成管理
/// </summary>
public class EffectManager : SingletonClass<EffectManager>
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// エフェクト名
	/// </summary>
	[SerializeField] string[] effectNames = null;
	/// <summary>
	/// エフェクトオブジェクト
	/// </summary>
	[SerializeField] GameObject[] effectObjs = null;
	/// <summary>
	/// エフェクト格納
	/// </summary>
	Dictionary<string,GameObject> effects;
	//-------------------------------------------------------------------------------
	protected override void AwakeInitialize()
	{
		DontDestroyOnLoad(gameObject.transform.root);

		//エフェクト
		this.effects = new Dictionary<string, GameObject>();
		//エフェクト名分設定
		for(int i = 0; i < this.effectNames.Length; i++)
		{
			this.effects[this.effectNames[i]] = this.effectObjs[i];
		}

	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// エフェクトオブジェクト生成
	/// </summary>
	/// <param name="eName">生成するエフェクト名</param>
	/// <returns></returns>
	public GameObject EffectGenerate(string eName)
	{
		//エフェクト名が登録されていなかったら処理せず
		if (!this.effects.ContainsKey(eName)) { Debug.LogWarning("エフェクト名が登録されていませんでした。：" + eName); return null; }

		//生成する
		GameObject obj = Instantiate(this.effects[eName],gameObject.transform);

		return obj;
	}

	/// <summary>
	/// エフェクトオブジェクト生成
	/// </summary>
	/// <param name="eName">生成するエフェクト名</param>
	/// <param name="pos">生成位置</param>
	/// <returns></returns>
	public GameObject EffectGenerate(string eName,Vector2 pos)
	{
		//エフェクト名が登録されていなかったら処理せず
		if (!this.effects.ContainsKey(eName)) { Debug.LogWarning("エフェクト名が登録されていませんでした。：" + eName); return null; }

		//生成する
		GameObject obj = Instantiate(this.effects[eName],gameObject.transform);
		//位置
		obj.transform.position = pos;

		return obj;
	}
	//-------------------------------------------------------------------------------
}
