﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//-------------------------------------------------------------------------------
/// <summary>
/// デバック管理クラス
/// </summary>
public class DebugManager : SingletonClass<DebugManager>
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// デバックモードか
    /// </summary>
    public bool isDebug;
    /// <summary>
    /// デバックモード起動用キー
    /// </summary>
    [SerializeField] KeyCode debugKey = KeyCode.None;
    /// <summary>
    /// デバックUI
    /// </summary>
    [SerializeField] Canvas debugCanvas = null;
    /// <summary>
    /// デバック命令入力
    /// </summary>
    [SerializeField] InputField inputField = null;
    //-------------------------------------------------------------------------------
    void Start()
    {

        DontDestroyOnLoad(gameObject);
        this.isDebug = false;
        this.debugCanvas.gameObject.SetActive(this.isDebug);
    }
    //-------------------------------------------------------------------------------
    void Update()
    {
        //デバックモード切替
        if(Input.GetKeyDown(this.debugKey))
		{
            this.isDebug = !this.isDebug;
            this.debugCanvas.gameObject.SetActive(this.isDebug);
        }
        //デバックモードでない場合、処理せず
        if (!this.isDebug) { return; }
        
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// デバックメッセージ設定
    /// </summary>
    /// <param name="message_">入力された文字列</param>
    public void SetDebugMessage(string message_)
	{
        //デバック命令
        DebugOrder(message_.Split(','));

        //命令入力非表示
        this.inputField.text = "";
	}
    //-------------------------------------------------------------------------------
    //メッセージの内容ごとに命令変更
    void DebugOrder(string[] message_)
	{
        switch(message_[0])
		{
            //テレポート命令
            case "teleport":DebugTeleport(message_); break;
            //生成命令
            case "appear":  break;
            //経過時間変更命令
            case "time":    break;
            //シーン切り替え命令
            case "scene":   SceneChangeManager.Instance.SceneChange(message_[1]); break;
            //BGM
            case "bgm":     BGMController.Instance.Play(message_[1]); break;
            //SE
            case "se":      SEController.Instance.Play(message_[1]); break;
		}
	}
    //-------------------------------------------------------------------------------
    //テレポート命令
    void DebugTeleport(string[] message_)
	{
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        Vector2 pos = new Vector2(float.Parse(message_[1]), float.Parse(message_[2]));

        //強制テレポート
        player.transform.position = pos;

        Debug.Log("テレポートしました：x" + pos.x.ToString("F2") + " y" + pos.y.ToString("F2"));
	}
    //-------------------------------------------------------------------------------
    //生成命令
    void DebugAppear()
	{

	}
    //-------------------------------------------------------------------------------
    //経過時間変更命令
    void DebugTimeChange()
	{

	}
    //-------------------------------------------------------------------------------
}
