﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//---------------------------------------------
/// <summary>
/// カタログでのアイテム情報表示
/// </summary>
public class CatalogItemInfoController : ItemInfoController
{
    //---------------------------------------------
    /// <summary>
    /// アイテムカテゴリ名表示テキスト
    /// </summary>
    [SerializeField] Text icText = default;
    //---------------------------------------------
    public override void UIUpdate()
    {
        //アイテム無しなら処理せず
        if (this.itemNum <= 0) { return; }

        base.UIUpdate();


        //金額設定
        this.itemPrice = this.item.Price;


        //反映
        this.icText.text = ItemManager.Instance.GetItemName(this.item.ICategory);
        //金額表示
        this.priceText.text = this.itemPrice.ToString() + "G";
    }

}
