﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// 実行されたか返す
/// </summary>
/// <returns></returns>
public delegate bool IsAction();
//-------------------------------------------------------------------------------
/// <summary>
/// イベントシステム統括
/// </summary>
public class EventManager : SingletonClass<EventManager>
{
	/// <summary>
	/// イベント状態か
	/// </summary>
	public  bool isEvent;

	/// <summary>
	/// 登録するイベント名
	/// </summary>
	public string[] eventDataNames;

	/// <summary>
	/// イベント開始前にフラグチェックをするイベント名
	/// </summary>
	[SerializeField] string[] eventCheckNames = new string[]{ };

	/// <summary>
	/// イベントフラグ名に名前があるか
	/// </summary>
	bool isEventFlag;
	//-------------------------------------------------------------------------------
	/// <summary>
	/// イベント処理確認
	/// </summary>
	/// <param name="eventName">イベント名</param>
	public void EventStart(string eventName)
	{
		//イベントリストをチェック
		bool isExist = false;
		foreach (string eName in this.eventDataNames)
		{
			if(eName == eventName) { isExist = true; break; }
		}
		//イベント名がない場合、処理終了
		if (isExist == false) { Debug.LogError("該当するイベント処理がありませんでした：" + eventName); return; }

		//チェックするイベント名かチェック
		bool isEnd = false;
		foreach(string eName in this.eventCheckNames)
		{
			this.isEventFlag = (eName == eventName);
			//存在する場合
			if(this.isEventFlag)
			{
				//イベント終了済みか受け取る
				isEnd = PlayData.Instance.eventData.CheckEventFlag(eName);
				break;
			}
		}
		//イベント終了済みの場合、処理終了
		if (isEnd) { Debug.Log("このイベントは終了しています:" + eventName); return; }

		//イベントスタート
		StartCoroutine(EventEngine(eventName));

	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 非同期イベントスタート
	/// </summary>
	/// <param name="data">実行するイベントテキスト</param>
	/// <returns></returns>
	IEnumerator EventEngine(string eventName)
	{
		//イベントファイル読み込み
		List<string> data = FileLoad.DataLoadResource(eventName);

		//イベント状態をONに
		this.isEvent = true;


		//ループ
		for(int n = 0; n < data.Count; n++)
		{
			//終了条件
			IsAction action = (()=>true);
			//イベント終了フラグ
			bool isEnd = false;

			//先頭要素によって処理変更
			switch(data[n].Split(',')[0])
			{
				//オブジェクト有効化
				case "on":	EventObject.Instance.ObjectActive(data[n].Split(',')[1], true); break;
				//オブジェクト無効化
				case "off": EventObject.Instance.ObjectActive(data[n].Split(',')[1], false); break;
				//メッセージ表示
				case "msg":
					{
						EventMessage.Instance.MessageActive(data[n].Split(',')[1]);
						//終了条件
						action = EventMessage.Instance.MessageAction(data[n].Split(',')[2]);
						break;
					}
				//シーン切り替え
				case "scene":	SceneChangeManager.Instance.SceneChange(data[n].Split(',')[1]); break;
				//イベント終了
				case "end":		isEnd = true; break;
			}

			//終了条件が満たされるまで待機 (メニュー中も待機)
			yield return new WaitUntil(() => action() && !MenuManager.Instance.isMenuActive);
			yield return null;

			//フラグがONなら強制終了
			if (isEnd) { break; }
		}


		//イベント終了
		this.isEvent = false;

		//イベントフラグに存在する場合
		if (this.isEventFlag) 
		{
			//イベントフラグを終了済みにする
			PlayData.Instance.eventData.EventEnd(eventName);
		}

		//終了処理
		EventMessage.Instance.MessageEnd();	//メッセージ終了

		yield break;
	}
	//-------------------------------------------------------------------------------
}
