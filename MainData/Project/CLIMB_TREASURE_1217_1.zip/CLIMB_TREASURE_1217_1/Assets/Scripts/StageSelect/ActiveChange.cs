﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 有効・無効
/// </summary>
public class ActiveChange : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 時間延長の有効無効テキスト
	/// </summary>
	[SerializeField] TextChange timeExtendTextClass = null;
	/// <summary>
	/// レアリティアップ有効無効テキスト
	/// </summary>
	[SerializeField] TextChange rarityUpTextClass = null;
	//-------------------------------------------------------------------------------
	/// <summary>
	/// 時間延長の有効・無効化
	/// </summary>
	public void TimeExtendActive()
	{
		//有効化する際
		if (!TimeExtend.Instance.isActive) 
		{
			//金額計算			
			if (PlayData.Instance.money < TimeExtend.Instance.price) 
			{
				//必要金額が足りない場合、処理せず
				return;
			}
			else
			{
				//金額を差し引く
				PlayData.Instance.money -= TimeExtend.Instance.price;
			}
		}
		//無効化する場合
		else 
		{
			//払い戻し
			PlayData.Instance.money += TimeExtend.Instance.price;
		}

		//変更処理
		TimeExtend.Instance.isActive = !TimeExtend.Instance.isActive;
		this.timeExtendTextClass.Active();
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// レアリティアップの有効・無効化
	/// </summary>
	public void RarityUpActive()
	{
		//有効化する際
		if (!RarityUp.Instance.isActive)
		{
			//金額計算			
			if (PlayData.Instance.money < RarityUp.Instance.price)
			{
				//必要金額が足りない場合、処理せず
				return;
			}
			else
			{
				//金額を差し引く
				PlayData.Instance.money -= RarityUp.Instance.price;
			}
		}
		//無効化する場合
		else
		{
			//払い戻し
			PlayData.Instance.money += RarityUp.Instance.price;
		}

		//変更処理
		RarityUp.Instance.isActive = !RarityUp.Instance.isActive;
		this.rarityUpTextClass.Active();
	}
	//-------------------------------------------------------------------------------
}
