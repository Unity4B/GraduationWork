﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// プレイデータ
/// </summary>
public class PlayData : SingletonClass<PlayData>
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// アイテムを持てる量
    /// </summary>
    [Header("持てるアイテムの量")]
    [SerializeField] int hasItemValue = 0;
    /// <summary>
    /// 所持アイテムの番号
    /// </summary>
    [SerializeField] public int[] itemNums;
    /// <summary>
    /// 所持金
    /// </summary>
    [SerializeField] public int money;
    /// <summary>
    /// アイテムをゲットしたことがあるか
    /// </summary>
    public bool[] isGotItems;
    //-------------------------------------------------------------------------------
    protected override void AwakeInitialize()
	{
        DontDestroyOnLoad(gameObject);
    }
    //-------------------------------------------------------------------------------
    void Start()
    {
        //ItemManagerのAwake後に呼び出さないとエラー?

        //初期化
        this.itemNums = new int[this.hasItemValue];
        for(int i = 0; i < this.itemNums.Length; i++)
		{
            this.itemNums[i] = -1;
		}

        this.money = 0;
        //アイテムの数だけ生成
        this.isGotItems = new bool[ItemManager.Instance.itemList.Count];
        for(int i = 0; i < this.isGotItems.Length;i++)
		{
            this.isGotItems[i] = false;
		}


        //セーブデータ読み込み
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// インベントリにアイテムを追加
    /// </summary>
    /// <param name="itemNum">追加するアイテム番号</param>
    public void AddItem(int itemNum)
	{
        //インベントリに空きがあるかチェック
        bool isNull = false;
        int num;
        for(num = 0; num < this.itemNums.Length; num++)
		{
            if(this.itemNums[num] == -1) { isNull = true; break; }
		}

        //もしインベントリが埋まっている場合、ほかのアイテムと入れ替えるか聞く
        if (isNull == false) { ItemSwapManager.Instance.ExistenceItemSwap(itemNum); return; }

        //インベントリに格納
        this.itemNums[num] = itemNum;
	}
    //-------------------------------------------------------------------------------
}
