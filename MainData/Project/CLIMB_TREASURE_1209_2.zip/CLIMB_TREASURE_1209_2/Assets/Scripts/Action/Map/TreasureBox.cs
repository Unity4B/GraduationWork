﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//-------------------------------------------------------------------------------
/// <summary>
/// 宝箱
/// </summary>
public class TreasureBox : MonoBehaviour
{
    //-------------------------------------------------------------------------------
    /// <summary>
    /// ステージで取得可能なアイテムカテゴリの配列
    /// </summary>
    public ItemManager.Category[] itemTable;
    /// <summary>
    /// すでに開けたか
    /// </summary>
    bool isOpen;
    /// <summary>
    /// 操作するアニメーター
    /// </summary>
    [SerializeField] Animator anim = null;
    [Header("格納しているアイテム番号")]
    [SerializeField] int itemNum = 1;
    //-------------------------------------------------------------------------------
    void Start()
    {
        //ステージのアイテムカテゴリテーブルを取得
        this.itemTable = ItemManager.Instance.stageItemCategory[SceneManager.GetActiveScene().name];

        this.isOpen = false;

        //仕様アイテムを使っている場合は特殊処理
        //抽選
        this.itemNum = ItemDraw();
    }
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 出るアイテムを抽選（出たアイテムの番号で返す）
    /// </summary>
    /// <returns>アイテム番号</returns>
    protected virtual int ItemDraw()
	{
        //ランダムにカテゴリを取得
        int tmp = Random.Range(0,this.itemTable.Length);

        //取得するアイテムカテゴリ決定
        int category = (int)this.itemTable[tmp];

        //アイテムのレア度確定
        tmp = Random.Range(1, 5);   // レア度１～４

        //アイテム番号決定
        return (category * 5) + tmp;

	}
    //-------------------------------------------------------------------------------
    //アイテムのレア度補正

    //-------------------------------------------------------------------------------
    /// <summary>
    /// 宝箱を開けるアニメーション
    /// </summary>
    void AnimationOpen()
	{
        anim.SetBool("isOpen", true);
	}
    //-------------------------------------------------------------------------------
    /// <summary>
    /// 格納しているアイテム番号を返す処理
    /// </summary>
    /// <returns></returns>
    public int GetItem()
	{
        this.isOpen = true;
        //アニメーション
        AnimationOpen();
        return this.itemNum;
	}
    //-------------------------------------------------------------------------------
    /// <summary>
    /// すでに開いているかチェック
    /// </summary>
    /// <returns></returns>
    public bool CheckOpen()
	{
        return isOpen;
    }
    //-------------------------------------------------------------------------------
}
