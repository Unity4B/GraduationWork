﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.UI;

//------------------------------------------------------
/// <summary>
/// Fade機能
/// </summary>
public class Fade
{
	//--------------------------------------------------------------------------
	/// <summary>
	/// Fade状態
	/// </summary>
	enum FadeState { None, In, Out };
	//--------------------------------------------------------------------------
	//フィールド
	/// <summary>
	/// 変化するカラー
	/// </summary>
	Color		fadeColor;
	/// <summary>
	/// Fade状態
	/// </summary>
	FadeState	fadeState;
	/// <summary>
	/// 時間計測
	/// </summary>
	float		deltaTime;
	//--------------------------------------------------------------------------
	/// <summary>
	/// コンストラクタ
	/// </summary>
	/// <param name="color">Fadeするカラー</param>
	public Fade(Color color)
	{
		this.fadeColor = color;
		this.fadeState = FadeState.In;
		this.deltaTime = 0.0f;
	}
	//--------------------------------------------------------------------------
	/// <summary>
	/// FadeIn処理(１フレーム)
	/// </summary>
	/// <param name="fadeTime">Fadeする時間</param>
	public void FadeIn(float fadeTime)
	{
		this.fadeColor -= new Color(0.0f, 0.0f, 0.0f, Time.deltaTime / fadeTime);
	}
	//--------------------------------------------------------------------------
	/// <summary>
	/// FadeOut処理(１フレーム)
	/// </summary>
	/// <param name="fadeTime">Fadeする時間</param>
	public void FadeOut(float fadeTime)
	{
		this.fadeColor += new Color(0.0f, 0.0f, 0.0f, Time.deltaTime / fadeTime);
	}
	//--------------------------------------------------------------------------
	/// <summary>
	/// FadeInOut処理(１フレーム)
	/// </summary>
	/// <param name="fadeTime">Fadeする時間</param>
	public void FadeInOut(float fadeTime)
	{
		if (this.fadeColor.a >= 1.0f) { this.fadeState = FadeState.In; }
		else if (this.fadeColor.a <= 0.0f) { this.fadeState = FadeState.Out; }

		if (this.fadeState == FadeState.In) { FadeIn(fadeTime); }
		else { FadeOut(fadeTime); }
	}

	/// <summary>
	/// FadeInOut処理(１フレーム)　
	/// </summary>
	/// <param name="fadeInTime">FadeInする時間</param>
	/// <param name="fadeOutTime">FadeOutする時間</param>
	public void FadeInOut(float fadeInTime, float fadeOutTime)
	{
		if (this.fadeColor.a >= 1.0f) { this.fadeState = FadeState.In; }
		else if (this.fadeColor.a <= 0.0f) { this.fadeState = FadeState.Out; }

		if (this.fadeState == FadeState.In) { FadeIn(fadeInTime); }
		else { FadeOut(fadeOutTime); }
	}

	/// <summary>
	/// FadeInOut処理(１フレーム)　
	/// </summary>
	/// <param name="fadeInTime">FadeInする時間</param>
	/// <param name="fadeOutTime">FadeOutする時間</param>
	/// <param name="fadeNoneTime">FadeOut後～FadeIn開始までの時間</param>
	public void FadeInOut(float fadeInTime, float fadeOutTime, float fadeNoneTime)
	{
		if (this.fadeColor.a >= 1.0f) { this.fadeState = FadeState.None; }
		else if (this.fadeColor.a <= 0.0f) { this.fadeState = FadeState.Out; }

		switch (this.fadeState)
		{
			//Fade処理ストップ
			case FadeState.None:
				if (fadeNoneTime < this.deltaTime)
				{
					this.fadeState = FadeState.In;
					this.deltaTime = 0.0f;
					FadeIn(fadeInTime);
				}
				else
				{
					this.deltaTime += Time.deltaTime;
				}
				break;
			//FadeIn
			case FadeState.In: FadeIn(fadeInTime); break;
			//FadeOut
			case FadeState.Out: FadeOut(fadeOutTime); break;
		}
	}
	//--------------------------------------------------------------------------
	/// <summary>
	/// Fade後のカラーを返す
	/// </summary>
	/// <returns>現在のカラー</returns>
	public Color GetColor()
	{
		return this.fadeColor;
	}
	//--------------------------------------------------------------------------
	/// <summary>
	/// FadeInが終わっているか
	/// </summary>
	/// <returns>結果</returns>
	public bool CheckFadeInEnd()
	{
		return this.fadeColor.a <= 0.0f;
	}
	//--------------------------------------------------------------------------
	/// <summary>
	/// FadeOutが終わっているか
	/// </summary>
	/// <returns>結果</returns>
	public bool CheckFadeOutEnd()
	{
		return this.fadeColor.a >= 1.0f;
	}
	//--------------------------------------------------------------------------
}
