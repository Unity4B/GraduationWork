﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// イベント管理
/// </summary>
public class EventManager : SingletonClass<EventManager>
{
	
}