﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputTest : MonoBehaviour
{
    // Update is called once per frame
    void Update()
    {
        if(Input.GetAxis("D_Pad_H") != 0.0f) { Debug.Log("D_Pad_H:" + Input.GetAxis("D_Pad_H")); }
        if(Input.GetAxis("D_Pad_V") != 0.0f) { Debug.Log("D_Pad_V:" + Input.GetAxis("D_Pad_V")); }
    }
}
