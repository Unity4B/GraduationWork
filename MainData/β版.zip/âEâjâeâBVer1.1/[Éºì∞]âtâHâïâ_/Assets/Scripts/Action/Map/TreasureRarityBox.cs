﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// 高レアアイテム確定ボックス
/// </summary>
public class TreasureRarityBox : TreasureBox
{
    //-------------------------------------------------------------------------------
    protected override int ItemDraw()
	{
        //ランダムにカテゴリを取得
        int tmp = Random.Range(0,this.itemTable.Length);

        //取得するアイテムカテゴリ決定
        int category = (int)this.itemTable[tmp];

        //アイテムのレア度確定
        tmp = 5;   // レア度１～４

        //アイテム番号決定
        return (category * 5) + tmp;
    }
}
