﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 宝箱からのアイテムのレアリティを上げる
/// </summary>
public class RarityUp : SingletonClass<RarityUp>
{
	/// <summary>
	/// 有効か無効か
	/// </summary>
	public bool isActive;
	/// <summary>
	/// レアリティアップの確率
	/// </summary>
	[Header("レアリティアップの確率(%)")]
	[SerializeField] int rarityUpProbability = 0;
	/// <summary>
	/// 必要金額
	/// </summary>
	[Header("必要金額")]
	public int price = 1000;
	//-------------------------------------------------------------------------------
	protected override void AwakeInitialize()
	{
		DontDestroyOnLoad(gameObject);
		this.isActive = false;
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// レアリティアップするか
	/// </summary>
	/// <returns></returns>
	public bool CheckRarityUP()
	{
		if (!this.isActive) { return false; }

		//ランダムな値決定
		int num = Random.Range(1,101);  //1～100

		//確率の値以下の場合、レアリティアップ
		if (num <= this.rarityUpProbability) { return true; }
		else { return false; }
	}
	//-------------------------------------------------------------------------------
}
