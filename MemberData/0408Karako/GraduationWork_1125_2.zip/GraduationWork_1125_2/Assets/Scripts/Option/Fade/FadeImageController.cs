﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//------------------------------------------------------
/// <summary>
/// Fadeの種類
/// </summary>
public enum FadeType
{
	None,   //無し
	In,     //イン
	Out,    //アウト
	InOut,  //インアウト
	OutIn,  //アウトイン
}
//------------------------------------------------------
/// <summary>
/// FadeImageの構造体
/// </summary>
[System.Serializable]
public struct FadeImageData
{
	/// <summary>
	/// FadeInする時間
	/// </summary>
	public float fadeInTime;
	/// <summary>
	/// FadeOutする時間
	/// </summary>
	public float fadeOutTime;
	/// <summary>
	/// Fadeに使う色
	/// </summary>
	public Color fadeColor;
	//------------------------------------------------------
	/// <summary>
	/// Fade処理開始
	/// </summary>
	/// <param name="type">Fadeする種類</param>
	public void FadeStart(FadeType type)
	{
		//種類ごとに処理変更
		switch (type)
		{
			case FadeType.In: FadeImageController.Instance.FadeStart(type, this.fadeInTime, this.fadeColor); break;
			case FadeType.Out: FadeImageController.Instance.FadeStart(type, this.fadeOutTime, this.fadeColor); break;
			case FadeType.InOut: FadeImageController.Instance.FadeStart(type, this.fadeInTime, this.fadeColor); break;
			case FadeType.OutIn: FadeImageController.Instance.FadeStart(type, this.fadeOutTime, this.fadeColor); break;
		}
	}
}
//------------------------------------------------------
/// <summary>
/// UI　フェード表示
/// </summary>
public class FadeImageController : SingletonClass<FadeImageController>
{
	//フィールド
	/// <summary>
	/// Fade機能
	/// </summary>
	Fade					fadeClass;
	/// <summary>
	/// 反映するImage
	/// </summary>
	[SerializeField] Image	fadeImage = null;
	/// <summary>
	/// フェードタイプ
	/// </summary>
	FadeType				fType;
	/// <summary>
	/// フェードする時間
	/// </summary>
	float					fadeTime;
	//------------------------------------------------------
	protected override void Awake()
	{
		base.Awake();

		this.fadeClass	= new Fade(this.fadeImage.color);
		this.fType		= FadeType.None;
	}

	void Update()
	{
		//種類ごとに処理変更
		switch (this.fType)
		{
			//FadeIn
			case FadeType.In:
				this.fadeClass.FadeIn(this.fadeTime);

				//FadeInが終わっているか
				if (this.fadeClass.CheckFadeInEnd())
				{
					this.fType = FadeType.None;
				}
				break;

			//FadeOut
			case FadeType.Out:
				this.fadeClass.FadeOut(this.fadeTime);

				//FadeOutが終わっているか
				if (this.fadeClass.CheckFadeOutEnd())
				{
					this.fType = FadeType.None;
				}
				break;

			//FadeInOut
			case FadeType.InOut:
				this.fadeClass.FadeInOut(this.fadeTime);

				//Fadeが終わっているか
				if (this.fadeClass.CheckFadeOutEnd())
				{
					this.fType = FadeType.None;
				}
				break;

			//FadeOutIn
			case FadeType.OutIn:
				this.fadeClass.FadeInOut(this.fadeTime);

				//Fadeが終わっているか
				if (this.fadeClass.CheckFadeInEnd())
				{
					this.fType = FadeType.None;
				}
				break;
		}

		//更新
		this.fadeImage.color = this.fadeClass.GetColor();
	}
	//------------------------------------------------------
	/// <summary>
	/// Fade処理開始
	/// </summary>
	/// <param name="type">実行するフェードの種類</param>
	/// <param name="time">フェードする時間</param>
	/// <param name="color">色</param>
	public void FadeStart(FadeType type, float time, Color color)
	{
		//種類ごとに処理変更
		switch (type)
		{
			case FadeType.In:		this.fadeImage.color = new Color(color.r, color.g, color.b, 1.0f); break;
			case FadeType.Out:		this.fadeImage.color = new Color(color.r, color.g, color.b, 0.0f); break;
			case FadeType.InOut:	this.fadeImage.color = new Color(color.r, color.g, color.b, 1.0f); break;
			case FadeType.OutIn:	this.fadeImage.color = new Color(color.r, color.g, color.b, 0.0f); break;
		}
		this.fadeClass	= new Fade(this.fadeImage.color);
		this.fType		= type;
		this.fadeTime	= time;
	}
	//------------------------------------------------------
	/// <summary>
	/// フェード中かチェック
	/// </summary>
	/// <returns></returns>
	public bool CheckFadeNow()
	{
		return this.fType != FadeType.None;
	}
	//------------------------------------------------------
}
