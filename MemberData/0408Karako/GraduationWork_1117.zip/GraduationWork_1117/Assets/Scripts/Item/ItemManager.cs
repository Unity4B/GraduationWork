﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// アイテム管理
/// </summary>
public class ItemManager : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	//アイテムリスト

	//アイテムデータの読み込み・反映


	//
}
