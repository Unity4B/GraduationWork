﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// アイテムの種類
/// </summary>
public enum ItemCategory
{

}
//-------------------------------------------------------------------------------
/// <summary>
/// アイテムクラス
/// </summary>
public class Item : MonoBehaviour
{
	//-------------------------------------------------------------------------------
	//アイテム番号

	//アイテム名

	//カテゴリ名

	//値段


}
