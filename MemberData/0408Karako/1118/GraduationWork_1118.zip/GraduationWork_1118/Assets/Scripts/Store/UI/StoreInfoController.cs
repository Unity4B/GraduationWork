﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//---------------------------------------------
/// <summary>
/// 店情報の表記
/// </summary>
public class StoreInfoController : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
