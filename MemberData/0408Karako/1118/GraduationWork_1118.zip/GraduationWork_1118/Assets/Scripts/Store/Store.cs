﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//---------------------------------------------
/// <summary>
/// 店
/// </summary>
public class Store
{
    //---------------------------------------------
    /// <summary>
    /// 店カテゴリ
    /// </summary>
    StoreCategory sCategory;
    /// <summary>
    /// ボーナスアイテム
    /// </summary>
    ItemCategory[] bonusItems = new ItemCategory[2];
    //---------------------------------------------
    //プロパティ
    /// <summary>
    /// 店カテゴリ
    /// </summary>
    public StoreCategory SCategory
	{
        private set { this.sCategory = value; }
        get { return this.sCategory; }
    }
    /// <summary>
    /// ボーナスアイテム
    /// </summary>
    public ItemCategory[] BonusItems
	{
		private set { this.bonusItems = value;}
		get { return this.bonusItems; }
	}
	//---------------------------------------------
    /// <summary>
    /// コンストラクタ
    /// </summary>
    /// <param name="sCategory_">店カテゴリ</param>
    /// <param name="bonusItems">ボーナスアイテム</param>
    public Store(StoreCategory sCategory_,ItemCategory[] bonusItems)
	{
        SCategory = sCategory_;
        BonusItems = bonusItems;
	}

}
