﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StoreSelecter : MonoBehaviour
{
    [SerializeField] GameObject[] storeImage = null;
    int storeCount;
    [SerializeField] int nowStore = 0;
    // Start is called before the first frame update
    void Start()
    {
        this.storeCount = 6;
    }

    // Update is called once per frame
    void Update()
    {
        //前フレームに選択中の店を灰色に戻す
        int preStore = this.nowStore;
        this.storeImage[preStore].GetComponent<Image>().color= new Color32(128, 128, 128, 255);
        //十字キー（仮）で選択
        /*　0　1　2
          　3　4　5　*/
        if (Input.GetKeyDown(KeyCode.LeftArrow)) this.nowStore--;   //←
        if (Input.GetKeyDown(KeyCode.RightArrow)) this.nowStore++;  //→
        if (Input.GetKeyDown(KeyCode.UpArrow)) this.nowStore -= 3;  //↑
        if (Input.GetKeyDown(KeyCode.DownArrow)) this.nowStore += 3;//↓
        //マイナスか最大数超過の時、反対側へ戻す
        if (this.nowStore < 0) this.nowStore += this.storeCount;
        if (this.nowStore >= this.storeCount) this.nowStore -= this.storeCount;
        //選択中の店を強調させる
        this.storeImage[this.nowStore].GetComponent<Image>().color = new Color32(255, 255, 255, 255);


        //StoreManager.Instance.SetStoreSelect(0);
    }
}
