﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//---------------------------------------------
/// <summary>
/// 店カテゴリ
/// </summary>
public enum StoreCategory
{
    NONE = -1,
    /// <summary>
    /// 薬屋
    /// </summary>
    Medicin = 0,

}
//---------------------------------------------
/// <summary>
/// 店管理
/// </summary>
public class StoreManager : SingletonClass<StoreManager>
{
    //---------------------------------------------
    /// <summary>
    /// 店リスト
    /// </summary>
    public Store[] storeList;
    /// <summary>
    /// 選ばれた店
    /// </summary>
    Store storeSelect;
    //---------------------------------------------
    //プロパティ
    /// <summary>
    /// 選ばれた店
    /// </summary>
    public Store StoreSelect
	{
        private set { this.storeSelect = value; }
		get { return this.storeSelect; }
	}
    //---------------------------------------------
    protected override void Awake()
    {
        base.Awake();

        //店設定
        this.storeList = new Store[] 
        {
            new Store(StoreCategory.Medicin, new ItemCategory[] { ItemCategory.PLANT}), //薬屋
        };
        SetStoreSelect(0);
    }
    //---------------------------------------------
    /// <summary>
    /// 店をセット
    /// </summary>
    /// <param name="num">選ばれた店番号</param>
    public void SetStoreSelect(int num)
	{
        StoreSelect = this.storeList[num];
	}
    //---------------------------------------------


}
