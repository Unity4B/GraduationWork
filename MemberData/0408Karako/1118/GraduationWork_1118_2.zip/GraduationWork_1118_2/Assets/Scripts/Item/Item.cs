﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// アイテムの種類
/// </summary>
public enum ItemCategory
{
	NONE = -1,
	PLANT = 0,	//植物

}
//-------------------------------------------------------------------------------
/// <summary>
/// アイテムクラス
/// </summary>
public class Item
{
	//-------------------------------------------------------------------------------
	//アイテム番号
	int num;
	//アイテム名
	string iName;
	//カテゴリ名
	ItemCategory category;
	//値段
	int price;
	//-------------------------------------------------------------------------------
	//プロパティ
	//アイテム番号
	public int Num
	{
		private set { this.num = value; }
		get { return this.num; }
	}
	//アイテム名
	public string IName
	{
		private set { this.iName = value; }
		get	{ return this.iName; }
	}
	//カテゴリ名
	public ItemCategory Category
	{
		private set { this.category = value; }
		get { return this.category; }
	}
	//値段
	public int Price
	{
		private set { this.price = value; }
		get { return this.price; }
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// コンストラクタ
	/// </summary>
	/// <param name="num_">番号</param>
	/// <param name="iName_">アイテム名</param>
	/// <param name="category_">カテゴリ名</param>
	/// <param name="price_">値段</param>
	public Item(int num_, string iName_, ItemCategory category_, int price_)
	{
		Num = num_;
		IName = iName_;
		Category = category_;
		Price = price_;
	}
	//-------------------------------------------------------------------------------
}
