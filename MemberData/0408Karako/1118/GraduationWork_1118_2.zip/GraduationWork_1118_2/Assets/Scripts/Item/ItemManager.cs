﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------
/// <summary>
/// アイテム管理
/// </summary>
public class ItemManager : SingletonClass<ItemManager>
{
	//-------------------------------------------------------------------------------
	//アイテムリスト
	public static List<Item> itemList;
	//アイテム画像リスト
	public static Sprite[] itemSprites;
	//-------------------------------------------------------------------------------
	protected override void Awake()
	{
		base.Awake();

		//アイテムデータの読み込み
		itemList = new List<Item>();
		Instance.ItemDataLoad();	

		//アイテム画像の読み込み
		itemSprites = new Sprite[itemList.Count];
		Instance.ItemSpriteLoad();
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// アイテムデータの読み込み・反映
	/// </summary>
	void ItemDataLoad()
	{
		//テキストフェイルからアイテムデータを読み込む
		List<string> itemData = FileLoad.DataLoadResource("item");

		//要素分繰り返す
		for (int i = 0; i < itemData.Count; i++)
		{
			//文字列を分割してアイテムを作成
			string line = itemData[i];

			//文字列から作成するアイテムのカテゴリを決定
			ItemCategory itemCategory = ItemCategory.NONE;
			switch(line.Split(',')[2])
			{
				case "植物": itemCategory = ItemCategory.PLANT; break;
			}

			//アイテム作成
			Item item = new Item
				(
					int.Parse(line.Split(',')[0]),	//アイテム番号
					line.Split(',')[1],				//アイテム名
					itemCategory,					//アイテムカテゴリ
					int.Parse(line.Split(',')[3])	//値段
				);

			//アイテムリストに追加
			itemList.Add(item);
		}
	}
	//-------------------------------------------------------------------------------
	/// <summary>
	/// アイテム画像の読み込み・反映
	/// </summary>
	void ItemSpriteLoad()
	{
		//要素分繰り返す
		for(int i =0; i < itemSprites.Length;i++)
		{
			//読み込んで反映
			itemSprites[i] = FileLoad.SpriteDataLoadResource("item" + (i + 1).ToString());
		}
	}
}
