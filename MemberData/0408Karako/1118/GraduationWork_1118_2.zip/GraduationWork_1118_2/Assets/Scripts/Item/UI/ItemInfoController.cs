﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

//---------------------------------------------
/// <summary>
/// アイテム情報の表記
/// </summary>
public class ItemInfoController : MonoBehaviour
{
	//---------------------------------------------
	/// <summary>
	/// アイテム番号
	/// </summary>
	public int itemNum;
	/// <summary>
	/// アイテム画像表記イメージ
	/// </summary>
	[SerializeField] Image iImage = default;
	/// <summary>
	/// アイテム名表記テキスト
	/// </summary>
	[SerializeField] Text iNameText = default;
	/// <summary>
	/// 値段表記テキスト
	/// </summary>
	[SerializeField] Text priceText = default;
	/// <summary>
	/// ボーナス画像表記イメージ
	/// </summary>
	[SerializeField] Image bonusImage = default;
	/// <summary>
	/// アイテムの買取値段
	/// </summary>
	public int itemPrice;
	//---------------------------------------------
	void Start()
	{
		//表示したいアイテムの情報を受け取る
		Item item = ItemManager.itemList.FirstOrDefault(value => value.Num == this.itemNum);


		//ボーナス対象かチェック
		bool isBounus = false;
		for (int i = 0; i < StoreManager.Instance.StoreSelect.BonusItems.Length; i++)
		{
			if(item.Category == StoreManager.Instance.StoreSelect.BonusItems[i]) { isBounus = true; }
		}

		//ボーナス加算
		if (isBounus) { this.itemPrice = (int)((float)item.Price * 1.1f); }
		else { this.itemPrice = item.Price; }

		//テキストに反映
		this.iImage.sprite = ItemManager.itemSprites[item.Num - 1];
		this.iNameText.text = item.IName;
		this.priceText.text = this.itemPrice.ToString() + "G";
		this.bonusImage.enabled = isBounus;
	}


}
