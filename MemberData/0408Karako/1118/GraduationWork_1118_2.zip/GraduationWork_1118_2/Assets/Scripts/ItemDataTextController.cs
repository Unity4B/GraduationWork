﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItemDataTextController : MonoBehaviour
{
	[SerializeField] Text text = null;

	void Update()
	{
		string line =   ItemManager.itemList[0].Num.ToString() + "\n" +
						ItemManager.itemList[0].IName + "\n" +
						ItemManager.itemList[0].Category.ToString() + "\n" +
						ItemManager.itemList[0].Price.ToString() + "\n";
		this.text.text = line;
	}
}
