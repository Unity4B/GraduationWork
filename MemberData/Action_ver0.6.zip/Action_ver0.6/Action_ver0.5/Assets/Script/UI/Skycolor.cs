﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Skycolor : MonoBehaviour
{
    public Gradient gradient;
    [SerializeField] private GameObject SkyPanel;
    [SerializeField] private Timer clockManager;

    [Range(0, 1)]
    public float time = 0;

    void Update()
    {
        time = clockManager.timecount();
        SkyPanel.GetComponent<Renderer>().material.color = gradient.Evaluate(time);
    }
}
